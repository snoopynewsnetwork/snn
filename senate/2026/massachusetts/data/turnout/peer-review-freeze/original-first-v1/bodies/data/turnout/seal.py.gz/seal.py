#!/usr/bin/env python3
"""Seal all owned assets and pinned shared originals after offline validation."""
import hashlib,json,runpy,sys
from pathlib import Path
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;STATE=D.parent.parent
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def main():
    excluded={'asset-manifest.json','validation.json','final-seal.json'}
    paths=[STATE/'turnout.md',STATE/'data/county-turnout.csv']+[p for p in D.rglob('*')if p.is_file()and p.name not in excluded]
    assert not any('__pycache__'in p.parts or 'node_modules'in p.parts for p in paths)
    assets=[]
    for p in sorted(paths):
        b=p.read_bytes();assert len(b)<40_000_000;assets.append(dict(path=p.relative_to(STATE).as_posix(),bytes=len(b),sha256=sha(b)))
    reused=[]
    for r in json.loads((D/'source/shared-originals.json').read_bytes()):
        p=STATE/r['immutable_body_path'];reused.append(dict(path=r['immutable_body_path'],source_id=r['id'],raw_bytes=r['bytes'],raw_sha256=r['raw_sha256'],stored_bytes=p.stat().st_size,stored_sha256=r['stored_sha256']))
    for r in json.loads((D/'source/municipal-authority-originals.json').read_bytes()):reused.append(dict(path=r['asset_path'],source_id=r['id'],raw_bytes=r['raw_bytes'],raw_sha256=r['raw_sha256'],stored_bytes=r['stored_bytes'],stored_sha256=r['stored_sha256']))
    dump(D/'asset-manifest.json',dict(schema='MA-turnout-assets-v1',base='senate/2026/massachusetts',owned_assets=assets,reused_originals=reused,hash_cycle_exclusions=sorted(excluded),strict_byte_limit=40_000_000))
    dump(D/'final-seal.json',dict(status='pending_validation'))
    dump(D/'validation.json',dict(status='pending_validation'))
    runpy.run_path(str(D/'validate_turnout.py'),run_name='__main__')
    validation=json.loads((D/'validation.json').read_bytes());assert validation['status'].startswith('pass_')
    names=['asset-manifest.json','validation.json','priority-set.json']
    sealed={n:dict(bytes=(D/n).stat().st_size,sha256=sha((D/n).read_bytes()))for n in names}
    sealed['../../turnout.md']=dict(bytes=(STATE/'turnout.md').stat().st_size,sha256=sha((STATE/'turnout.md').read_bytes()))
    dump(D/'final-seal.json',dict(status='sealed_original_source_report_offline_QA_peer_and_coordinator_pending',sealed_files=sealed,independent_peer_agreement=validation['independent_peer_agreement'],coordinator_accepted=False))
    print('Final seal written; peer/coordinator acceptance remains explicitly pending.')
if __name__=='__main__':main()
