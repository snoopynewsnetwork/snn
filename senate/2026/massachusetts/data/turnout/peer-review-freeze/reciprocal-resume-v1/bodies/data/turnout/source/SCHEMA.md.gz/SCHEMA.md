# Massachusetts turnout source and output schema

The primary dispatch is **2,394 literal 2024 PD43 CSV City/Town, Ward, Pct contexts**, ranked by the two named source columns Elizabeth Ann Warren and John Deaton. All Others and Total Votes Cast are separate full sensitivities. No legal/write-in robustness, current boundary or 2026 volume inference is made.

`shared-originals.json` freezes individual launch receipts from the read-only newsroom preparation. `immutable_body_path` is relative to `senate/2026/massachusetts/`. It points to complete, immutable-by-hash HTTP entities compressed with gzip. Validate both raw and stored hashes and raw byte length. The appendable newsroom manifest is **not** a build dependency. Parent IDs/URLs, requested and final URLs, UTC retrieval, HTTP status, response headers, redirects, sizes and hashes survive in the frozen receipts. New `*.receipt.json` files use the same meanings, `requested_url`, `body_path`, `raw_bytes` and `stored_bytes`; original error bodies survive. Requests decodes wire Content-Encoding before storage, so raw means complete decoded response entity, not encrypted/wire bytes. No original is truncated or simplified. Every stored file must be strictly below 40,000,000 bytes.

`municipal-authority-originals.json` freezes three additional individual Worcester receipts and immutable bodies, independent of the mutable news ledger. Their results inventory and primary-titled stream are authority/access examples, not November 2026 count feeds.

`browser-*-observation.txt` retains the complete returned research-browser text observation, including source URLs and line positions. It is **not** original HTML/PDF/XLSX bytes. Browser HTTP headers and exact fetch time are unavailable. Corresponding direct HTTP 403 or alternate transport failures are preserved in receipts. These supplemental statewide statistics never supply inferred local counts. No original statistical workbook or registration PDF was successfully acquired in this assignment.

## CSV and HTML extraction

`extract/<contest>-original-extraction.json.gz` preserves every CSV record verbatim as strings in original order, including two ragged header records and each statewide footer. CSV record ordinals are **1-based logical records** (header=1, party row=2, data starts=3), not assumed physical line numbers. `extract/*-numeric-positions.json.gz` retains each municipal/native count cell, raw value, column label and 1-based source record/column position, including both separate CSV footers. Empty numeric cells parse to null, never zero; this selected set has no empty numeric count cells. Ragged party rows are not padded or relabeled. HTML candidate cards and every source table row/cell, attributes, county/locality IDs and candidate-ID-bearing header attributes survive separately. Full HTML originals retain all other page content.

The selected CSVs have no method, registration, separate under/overvote, numerical native ID, FIPS, central-absentee-board or split-style definition columns. Corresponding record fields are null. `Blanks` retains that literal source category: it is not silently renamed undervotes and is not a named vote. `TotalVotesCast` is the literal PD43 contest total including Blanks, separately reconciled to published election-wide ballot controls where available. `AllOthers` is an unallocated generic category which includes write-ins; no named/eligible/invalid allocation is claimed. All candidate columns and their party/ballot identities remain separate. CSV party text and HTML Write-In displays can disagree and are not reconciled by relabeling.

`context_type=unallocated_municipal_context` identifies a native-export record with both Ward/Pct empty (118 in 2022, each that municipality's sole native row). It preserves the source's limited allocation. Other rows are `literal_ward_precinct_context`; the label does not establish a physical polygon, polling site, split ballot style, board, or current precinct. No central/administrative identity is explicitly labeled in these CSVs; absence of a separate row does not mean those votes or processes are absent. Native administrative/method allocations remain unavailable, rather than a fabricated zero-count extra unit.

## Disjoint hierarchy and keys

Native keys are compact JSON arrays of **exact** `[City/Town,Ward,Pct]` strings; their scope is contest/year/source, never a cross-year join. Municipal keys use the exact municipal record tuple, normally `[City/Town,"",""]`. No case/spacing/leading-zero/letter/dash normalization occurs. The state FIPS is `25`. Municipal/native FIPS and numerical native IDs are null/blank because none is supplied by the selected CSV. HTML county numeric locality IDs are separate source observations, not substituted municipal/native IDs.

`priority-set.json` has `all_unit_order` (2,394 complete records), `ordered_priority_keys` (exact minimum native 80%), `ordered_top15_keys`, and `ordered_remainder_keys`. `all_parent_child_maps` includes all 351 parents and every native child in source and primary rank order, with parent control values. A child belongs to exactly one parent, and child values sum to the parent. Municipal parents overlap their children and cannot be added to them. Ward labels are grouping labels, not additional votes; no ward-total rows occur in the selected native CSV. County HTML is another overlapping presentation, retained only for discrepancies, never ranking input.

The contract's municipal order/min80 and native/municipal AllOthers/TBC orders are separately labeled sensitivities. Every available 2024 source-native constituent appears in `all_unit_order.source_record`. Historical originals/native contexts and controls are complete in their separate extraction assets, without a current or cross-year boundary crosswalk. Source units outside the primary priority remain in all state arithmetic.

## Rankings, weights and compatibility CSV

All rankings use descending integer volume, then the exact original City/Town, Ward, Pct literal tuple lexicographically, then original CSV ordinal only if needed. `share_exact` and `cumulative_share_exact` are rational strings; floating `weight` is convenient display only. Membership uses integers: the first n with `5*cumulative >= 4*statewide`; n-1 must fail. Sorting makes n a minimum cardinality. `alternative-order-presentation.json` preserves an explicit original-ordinal tie alternative and its position/membership effects; it does not replace the canonical order.

`data/county-turnout.csv` is a compatibility filename for the complete **native** ranking. It has 2,394 rows, zero county substitutions, each candidate/control, exact cumulative vote and share, source record/hash, and primary flags. Unavailable cells are empty, not zero. The 24 `orders/*.csv` files contain the full four-contest × two-level × three-volume orders, including all nonpriority units. `ranking-summaries.json` gives denominator, top15, preceding count/votes, crossing, min80, and remainder for every order. `sensitivity-impacts.json` gives actual native rank/membership changes, without legal robustness implications.

`statistics-controls.json` separately preserves source-scoped statewide registration, printed turnout total/rate and rounded method shares. The registration dates are 2020-10-24, 2022-10-29 and 2024-10-26, from the respective primary PDF's browser-visible title, whose raw download was blocked. Registered means the source's Registered Voters, without an active-only/eligible-population assumption. Rounded method percentages cannot yield exact integer method counts. No municipal/native registration or method ranking is constructed from missing local cells.

## Reproduction and seal

Run from any directory:

```sh
python3 -B senate/2026/massachusetts/data/turnout/acquire_chain.py
python3 -B senate/2026/massachusetts/data/turnout/build_turnout.py
python3 -B senate/2026/massachusetts/data/turnout/extract_statistics.py
python3 -B senate/2026/massachusetts/data/turnout/build_report.py
python3 -B senate/2026/massachusetts/data/turnout/seal.py
```

All offline parsing/build/calculation/validation uses Python standard library only. The optional online acquisition uses `requests` and follows the observed public form/election/download chain into a **new directory under data/turnout/** with `acquire_chain.py --refresh <absolute-new-owned-path>`. It never replaces the frozen evidence. `acquire.py --fetch URL KEY PARENT` supports bounded exact source probes. No dependency/cache directory is retained.

`asset-manifest.json` enumerates every owned asset except itself, validation and final seal to avoid hash cycles, and every immutable reused original with raw/stored hashes and sizes. `validation.json` checks independent original-byte extraction, all candidates/parents/native contexts, all 24 orders, integer crossings, exact weights, null semantics, discrepancies, input mutations, source hashes, full contract/hierarchy, links and byte bounds. `final-seal.json` hashes the manifest, validation, primary contract and report. Peer/coordinator approval fields remain false until actually provided; offline arithmetic success is not peer agreement or dispatch acceptance.
