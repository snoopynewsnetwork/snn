"""Acyclic owned payload manifest. Manifest/seal intentionally do not self-hash."""
import hashlib,json
from pathlib import Path
from county import R,js
STATE=R.parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 files=[p for p in R.rglob('*') if p.is_file() and p not in [R/'asset-manifest.json',R/'seal.json']]+[R.parent/'county-baselines.csv',STATE/'county-partisanship.md'];assets=[]
 for p in sorted(files):
  assert p.stat().st_size<40000000;assert '__pycache__' not in p.parts
  assets.append({'path':str(p.relative_to(STATE)),'bytes':p.stat().st_size,'sha256':sha(p)})
 js('asset-manifest.json',{'scope':'only owned baseline report/CSV/data; shared bodies pinned in source/shared-assets.json','self_hash_exclusions':['data/baselines/asset-manifest.json','data/baselines/seal.json'],'assets':assets})
 js('seal.json',{'manifest_sha256':sha(R/'asset-manifest.json'),'validation_sha256':sha(R/'validation.json'),'independent_pre_peer_witness_sha256':sha(R/'source/pre-peer-witness.json'),'assets':len(assets),'current_source_accepted':False,'geography_accepted':False,'coordinator_accepted':False})
 print((R/'seal.json').read_text())
if __name__=='__main__':main()
