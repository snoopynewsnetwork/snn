document.title = 'Park County, Wyoming, MapServer';
window.mapParent = pidn => {
  const filter = "(pidn in('" + pidn + "'))"; // eslint-disable-line quotes
  rwg.selection.clear();
  rwg.renderInfo(rwg.config.info_url + 'layers=parent&filter=' + filter, true);
}
const rwgInitParams = {
  // mapserv: 'https://w5.gwmap.us/cgi-bin/mapserv76.fcgi',
  mapserv: '/w5/cgi-bin/mapserv76.fcgi',
  utm_zone: '12',
  statePlane: 'EPSG:3738',
  geodesic: true,
  mapCoordSys: 'EPSG:3857',
  dataCoordSys: 'EPSG:3857',
  olView: {
    extent: [-12361594, 5429920, -12079515, 5625813],
    center: [-12153432, 5554516],
    zoom: 10.8, minZoom: 9, maxZoom: 21,
  },
  mapfile: 'MAP11',
  defaultImgTyp: 'png8g',
  otherMaps: {
    'Google': {active: true},
    'Bing': {active: true},
    'Google Earth': {active: true},
    'Pictometry Explorer': {active: (location.pathname.indexOf('assessor') > -1)}
  },
  sources: {
    lotnumbers: { url: 'json-data/lotnumbers.topo.json' },
    streetnum: { url: 'json-data/streetnum.topo.json' },
    address_pt: { url: 'json-data/address_pt.topo.json' },
    statefed: { url: 'json-data/statefed.topo.json' },
    subdiv: { url: 'json-data/subdiv.topo.json' },
    lraRange: { url: 'json-data/lra-range.topo.json' },
    lraCrop: { url: 'json-data/lra-crop.topo.json' },
    // roads: { url: 'json-data/roads.topo.json' },
    roads: {  // if OL throws "unimplemented" error, set apache headers content-encoding and content-type
      type: 'MVT',
      url: 'mvt/roads/{z}/{x}/{y}.pbf',
      maxZoom: 12,
    },
    cities: { url: 'json-data/towns.topo.json' },
    precinct: { // Includes house & senate.  Note that the topoJSON name "precinct2024" matches the postgres table name, not this source name "precinct"
      url: 'json-data/precinct2024.topo.json',
    },
    mask2023: { url: 'json-data/mask2023.topo.json' },
    a23: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTPB23-MP77Hnwq58',
    },
    a25: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTPB25-oenJczTttd',
    },
  },
  styles: {
    // mask: { fill: {color: '#fff'} },
    WYO: { fill: {color: "#AAAAFF"}},
    BLM: { fill: {color: [255,255,144]}},
    BOR: { fill: {color: "#FFAA2A"}},
    USF: { fill: {color: "#52FFAD"}},
    YEL: { fill: {color: "#CE92FF"}},
    subdiv: {
      fill: {color: [176, 96, 255]},
      stroke: { color: [0, 0, 128], width: 8 },
    },
    // LRArange
    R1: { fill: {color: "#BFBFBF"}},
    R2: { fill: {color: "#9DC0C0"}},
    R3: { fill: {color: "#DFC7AA"}},
    R4: { fill: {color: "#A1D197"}},
    R5: { fill: {color: "#E2A6A6"}},
    // LRAcrop
    C1: { fill: {color: "#BFBFBF"}},
    C2: { fill: {color: "#BFBFBF"}},
    C3: { fill: {color: "#9DC0C0"}},
    C4: { fill: {color: "#DFC7AA"}},
    C5: { fill: {color: "#A1D197"}},
    // precincts (see legend-only.map for notes re colors)
    "prct9-5": { fill: {color: "#4D800088"}},
    "prct9-7": { fill: {color: "#50505088"}},
    "prct10-1-1": { fill: {color: "#00FF0088"}},
    "prct10-1-2": { fill: {color: "#FF947088"}},
    "prct6-1-3": { fill: {color: "#FFC00088"}},
    "prct6-1-2": { fill: {color: "#00F0F088"}},
    "prct9-1": { fill: {color: "#FFE49088"}},
    "prct8-2": { fill: {color: "#FFA0D088"}},
    "prct3-2-1": { fill: {color: "#D0A0FF88"}},
    "prct6-1-1": { fill: {color: "#B3FF4088"}},
    "prct23-1": { fill: {color: "#FFA0D088"}},
    "prct10-2": { fill: {color: "#E0E0E088"}},
    "prct2-1": { fill: {color: "#FFC00088"}},
    "prct3-1": { fill: {color: "#A0C0FF88"}},
    "prct11-2": { fill: {color: "#FFFF0088"}},
    "prct4-2-2": { fill: {color: "#70A0FF88"}},
    "prct4-2-1": { fill: {color: "#B0B0B088"}},
    "prct21-1-1": { fill: {color: "#00D06888"}},
    "prct21-1-2": { fill: {color: "#A0E0FF88"}},
    "prct1-1": { fill: {color: "#FFA0A088"}},
    "prct16-1-1": { fill: {color: "#EDFFD088"}},
    "prct4-1": { fill: {color: "#FFFF9088"}},
    "prct3-2-2": { fill: {color: "#E0E00088"}},
    "prct4-2-3": { fill: {color: "#FF60B088"}},
    "prct24-1-2": { fill: {color: "#FFE49088"}},
    "prct25-1": { fill: {color: "#A0FFA088"}},
    "prct24-1-1": { fill: {color: "#A0FFFF88"}},
    "prct7-2": { fill: {color: "#8000FF88"}},
    "prct8-1": { fill: {color: "#A0E0FF88"}},
    "prct16-1-2": { fill: {color: "#C0900088"}},
    "prct8-3": { fill: {color: "#A0FFFF88"}},

    // house & senate
    hd24: { fill: {color: "#BFBFBF"}},
    hd25: { fill: {color: "#9DC0C0"}},
    hd26: { fill: {color: "#DFC7AA"}},
    hd28: { fill: {color: "#A1D197"}},
    hd50: { fill: {color: "#E2A6A6"}},
    sd18: { fill: {color: "#9DC0C0"}},
    sd19: { fill: {color: "#DFC7AA"}},
    sd20: { fill: {color: "#A1D197"}},
    address_pt: {
      circle: {
        radius: '2',
        fill: {color: 'red'}
      },
      text: {
        font: '9pt Arial, Helvetica, sans-serif',
        offsetY: 5,
        stroke: {color: 'white', width: 2}, // halo
        offsetY: -7,
        offsetX: -15,
      },
    },
    address: {
      text: {
        font: '9pt Arial, Helvetica, sans-serif',
        offsetY: 5,
        stroke: {color: 'white', width: 2}, // halo
        offsetY: -7,
        offsetX: -15,
      },
    },
    label: {
      text: {
        font: '12pt Times New Roman, Times, serif',
        fill: {color: '#000000'},
        stroke: {color: '#ffffff', width: 2}, // halo
      }
    },
    labelText: {
      text: {
        font: 'bold 12pt Arial, Helvetica, sans-serif',
        fill: {color: '#000'},
        stroke: {color: 'white', width: 2},
        overflow: true
      },
    },
    roadShadow: {
      stroke: {
        color: '#555555',
        width: 3,
      },
      zIndex: 0,
    },
    roadLine: {
      stroke: {},
      zIndex: 1,
    },
    roadLabel: {
      text: {
        placement: 'line',
        maxAngle: Math.PI / 12,
        font: 'bold 12px Arial',
        fill: {color: 'black'},
        stroke: {color: 'white', width: 1},  // do NOT quote the width!
        // offsetY: -8,
      },
      zIndex: 2,
    },
    poly: {fill:{color:'#fff'}},
  },
  olLayers: [
    /* */
    { name: 'a23',
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'mask2023',
          // style: () => rwg.styles.get('mask'),
          style: { 'fill-color': '#fff'},
          zIndex: 1,
        },
        { source: 'a23',
          extent: [-12208682, 5479770, -12085482, 5623708],
        },
      ]
    },
    { name: 'a25',
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'mask2023',
          // style: () => rwg.styles.get('mask'),
          style: { 'fill-color': '#fff'},
          zIndex: 1,
        },
        { source: 'a25',
          extent: [-12208682, 5479770, -12085482, 5623708],
        },
      ]
    },
    /* */
    { name: 'background', type: 'ImageWMS'},
    { name: "statefed",
      type: 'Vector',
      source: 'statefed',
      // zIndex: 2,
      opacity: 0.5,
      style: feature => {
        let c = feature.get('c').substring(0,3)
        let txt
        switch (c) {
          case 'WYO':
            txt = "State\nof\nWyoming"
            break;
          case 'BOR':
            txt = "Bureau\nof\nReclamation"
            break;
          case 'YEL':
            // txt = "Yellowstone\nNational\nPark"
            break;
          case 'USF':
            txt = "National\nForest"
            break;
          default:
            txt = c
            break;
        }
        return [
          rwg.styles.get(c),
          rwg.styles.get('label', {
            text: {text: txt},
            // geom: rwg.clipToExtent(feature),
          })
        ]
      },
    },
    { name: "cities",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'cities',
          // zIndex: 2,
          style: {'stroke-color': [102,51,0], 'stroke-width':5},
        },
        { type: 'Vector',
          source: 'cities',
          style: feature => rwg.styles.get(
            'labelText',
            {
              text: {text: feature.get('Name')},
              geom: feature => feature.getGeometry().getType() === 'Polygon' ?
                feature.getGeometry().getInteriorPoint() :
                feature.getGeometry().getInteriorPoints().getPoint(0) // MultiPolygon
            }
          ),
          zIndex: 7,
          declutter: true,
        },
      ]
    },
    { name: "subdiv",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'subdiv',
          style: () => rwg.styles.get('subdiv'),
          zIndex: 2,
          opacity: 0.4,
        },
        { type: 'Vector',
          source: 'subdiv',
          style: feature =>  rwg.styles.get('label', {
            text: {text: feature.get('t').wrap(9)},
            geom: rwg.pointInPolyInView(feature)}
          ),
          zIndex: 7,
          declutter: true,
        },
      ]
    },
    { name: "LRArange",
      type: 'Vector',
      source: 'lraRange',
      style: feature => {
        let c = feature.get('LRA')
        return [
          rwg.styles.get('R' + c),
          rwg.styles.get('label', {
            text: {text: c},
            geom: rwg.pointInPolyInView(feature)
          })
        ]
      },
      zIndex: 2,
      opacity: 0.75,
      visible: false
    },
    { name: "LRAcrop",
      type: 'Vector',
      source: 'lraCrop',
      style: feature => {
        let c = feature.get('Lra')
        return [
          rwg.styles.get('C' + c),
          rwg.styles.get('label', {
            text: {text: c},
            geom: rwg.pointInPolyInView(feature)
          })
        ]
      },
      zIndex: 2,
      opacity: 0.75,
      visible: false
    },
    { name: "precinct",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'precinct',
          style: feature => {
            /* if (feature.get('prct')) {  // get precincts and not house & senate
              return rwg.styles.get('poly', { fill: {color: feature.get('fillcolor') + '88' }})
            } */
            let precinct = feature.get('prct')
            if (precinct) {
              return rwg.styles.get('prct' + precinct)
            }
          }
        },
        { type: 'Vector',
          source: 'precinct',
          declutter: true,
          zIndex: 8,
          style: feature => {
            let precinct = feature.get('prct')
            if (precinct) { // get precincts and not house & senate
              let geom = rwg.pointInPolyInView(feature)
              if (geom) {
                let label = precinct + '\n' + feature.get('polling_place')
                return rwg.styles.get('labelText', {
                  text: {text: label},
                  geom: geom
                })
              }
            }
          },
        },
      ]
    },
    { name: "house",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'precinct',
          opacity: 0.75,
          style: feature => {
            let hd = feature.get('hd')
            if (hd) { // house districts, not senate or precincts
              return rwg.styles.get('hd' + hd)
            }
          },
        },
        { type: 'Vector',
          source: 'precinct',
          declutter: true,
          zIndex: 8,
          style: feature => {
            let hd = feature.get('hd')
            if (hd) { // house districts, not senate or precincts
              let geom = rwg.pointInPolyInView(feature)
              if (geom) {
                return(rwg.styles.get('labelText', {
                  text: {text: 'HD ' + hd},
                  geom: geom
                }))
              }
            }
          },
        },
      ]
    },
    { name: "senate",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'precinct',
          opacity: 0.75,
          style: feature => {
            let sd = feature.get('sd')
            if (sd) {
              return rwg.styles.get('sd' + sd)
            }
          },
        },
        { type: 'Vector',
          source: 'precinct',
          declutter: true,
          zIndex: 8,
          style: feature => {
            let sd = feature.get('sd')
            if (sd) {
              let geom = rwg.pointInPolyInView(feature)
              if (geom) {
                return(rwg.styles.get('labelText', {
                  text: {text: 'SD ' + sd},
                  geom: geom
                }))
              }
            }
          },
        },
      ]
    },
    { name: 'roads',
      type: 'VectorTile',
      source: 'roads',
      declutter: true,
      style: (feature, resolution) => {
        let priority = feature.get('p')
        let txt = feature.get('t')
        let color, width
        switch (true) { // resolution
          case (resolution < 3): // ~10k
            width = 5
            break
          case (resolution < 9): // ~30k
            width = 3
            break
          default:
            width = 1
        }
        switch (priority) {
          case 1:
            color = '#dc2500'
            width = width + 2
            break;
          case 2:
            color = [242, 191, 36],
            width = width + 1
            break;
          case 3:
            if (resolution > 20) return
            width = 2
            color = '#b2b2b2'
            break;			
          case 4:
            // if (resolution > 20) return	
            width = 2			
            color = '#287e3b'
            break;
          case 5:
            // if (resolution > 20) return	
            width = 2			
            color = '#a280d1'
            break;
          case 6:
            // if (resolution > 20) return		  
            width = 2
			color = '#436f8d'
            break;
        }
        // Build style array
        let style;
        if (priority >= 4 && priority <= 6) {			
            // No shadow for priority 4-6
            style = [
                rwg.styles.get('roadShadow', { stroke: { width: width + 0.5 } }),
                rwg.styles.get('roadLine', {
                    stroke: { width: width, color: color },
                }),
            ];
        } else {
            // Apply shadow + road line for other priorities
            style = [
                rwg.styles.get('roadShadow', { stroke: { width: width + 1 } }),
                rwg.styles.get('roadLine', {
                    stroke: { width: width, color: color },
                }),
            ];
        }
        if (txt) {
          /* // for topoJSON:
          let geom = rwg.clipToExtent(feature)
          if (geom) {
            style.push(
              rwg.styles.get('roadLabel', {
                text: {text: txt},
                geom: geom,
              })
            )
          }
          */  // for VectorTile:
          style.push(rwg.styles.get('roadLabel', { text: {text: txt}}))
        }
        return style
      }
    },
    { name: "lotnumber",
      type: 'Vector',
      source: 'lotnumbers',
      style: feature => rwg.styles.get('label', {text: {text: feature.get('n')}}),
      minZoom: 15,
      zIndex: 7,
      declutter: true,
    },
    { name: "streetnum",
      type: 'Vector',
      source: 'streetnum',
      style: feature => rwg.styles.get('address', { text: { text: feature.get('n')}}),
      minZoom: 15,
      zIndex: 7,
      declutter: true,
    },
    { name: 'address',
      type: 'Vector',
      source: 'address_pt',
      type: 'Vector',
      style: feature => rwg.styles.get('address_pt', { text: { text: feature.get('n')}}),
      declutter: true,
    },
  ],
  layerOptions: {
    // a23: {imgType: 'jpeg', olLyr: 'background'},
    a22: {imgType: 'jpeg', olLyr: 'background'},
    a20: {imgType: 'jpeg', olLyr: 'background'},
    a19: {imgType: 'jpeg', olLyr: 'background'},
    a17: {imgType: 'jpeg', olLyr: 'background'},
    a15: {imgType: 'jpeg', olLyr: 'background'},
    a12: {imgType: 'jpeg', olLyr: 'background'},
    a09: {imgType: 'jpeg', olLyr: 'background'},
    drg: {imgType: 'jpeg', olLyr: 'background'},
    precinct: { info: (records) => rwg.formatInfo(records,[
      ['Precinct'], ['Polling Place']
    ], 'Voter Precincts')},
    wellheads: { info: records => {
      let count = rwg.selection.wellheads.update(records);
      if (count) {
        return rwg.selection.wellheads.render(null, count + ' Wellhead(s)');
      }
    }},
    cornerrec: { info: records => rwg.formatInfo(records, [['noLabel']],'&nbsp;Survey Corner Record')},
    bldgpermit: { info: records => rwg.formatInfo(records,[
        ['Number'], ['Issued'], ['Type'], ['Approved Use'], ['Name'], ['Realware Number'],
      ],
      '&nbsp;Building Permit')},
    fema: { info: records => rwg.formatInfo(records, [['FEMA Flood Hazard Zone'],['FEMA FIRM Panel Number']])},
    school: { info: records => rwg.formatInfo(records, [['noLabel']], 'School District')},
    subdiv: { info: records=> rwg.formatInfo(records, [['noLabel']], 'Scanned Plats')},
    zoning: { info: records => rwg.formatInfo(records, [['noLabel']], 'County Zoning')},
    zoningpowell:   { info: records => rwg.formatInfo(records, [['noLabel']], 'Powell Zoning')},
    zoningcody:     { info: records => rwg.formatInfo(records, [['noLabel']], 'Cody Zoning')},
    zoningmeeteese: { info: records => rwg.formatInfo(records, [['noLabel']], 'Meeteese Zoning')},
    ownership: {
      info: records => {
        let count = rwg.selection.ownership.update(records);
        if (count) {
          rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
          rwg.historyManager.push();
          let s = count > 1 ? 's' : ''
          return rwg.selection.ownership.render( null,
            count + ' Parcel' + s + ' <a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel' + s + '</a>'
          );
        }
      }
    }
  },
  navbar: {
    jump2s: [
      {'Park County': [-12361594, 5429920, -12079515, 5625813]},
      {'Cody':        [-12149787, 5541018, -12131854, 5552393]},
      {'Meeteetse':   [-12120596, 5487878, -12116190, 5490635]},
      {'Powell':      [-12120292, 5574634, -12095459, 5590227]},
    ]
  },
  disclaimer: "Park County provides this map for illustrative purposes only and assumes no liability for actions taken by users based on information shown.",
  print: {
    disclaimer: "Park County provides this map for illustrative purposes only and assumes no liability for actions taken by users based on information shown.",
    title: "Park County Wyoming MapServer"
  },
  selectionSets: {
    ownership: [
      ['Pidn'],
      ['Account', dat => '<a href="javascript:rwg.detailTab(\'' +  dat + '\')" >Property Detail</a>' ],
      [''], // Parent Parcel
      ['Account', dat => '<a href="https://itax.tylertech.com/ParkWY/detail.aspx?taxid=00000' +  dat + '" target="_blank">Property Taxes</a>' ],
      ['Owner'], ['Mail Addr'], ['Mail Addr'], ['St Addr'],
      ['Deed'], ['Location'], ['Type'], ['Area'],
      [false, dat => rwg.mapFeatures(dat)],
      [false, dat => rwg.mapFeatures(dat)],
      ['Tax District'], ['LEA'], ['Neighborhood'], ['Value Measure'],
      ['Quality'], ['Condition'], ['Adjusted Year Built'], ['Effective Age']
    ],
    parent: [
      ['Pidn'],
      ['Account'],
      [''], // Parent Parcel
      ['Owner'], ['Mail Addr'], ['Mail Addr'], ['St Addr'],
      ['Deed'], ['Location'], ['Type'],
      ['Retired date'],['Retired by'],
      [false, dat => rwg.mapFeatures(dat)],
    ],
    wellheads:[['Well API Number'], ['Class'], ['Operator'], ['Well Name'], ['Bottom Hole'], ['Elevation GR'],['Elevation KB'], ['Total Depth'], ['Plug Back'], ['Target Formation'], ['Coal Bed'], ['Status'], ['Location']]
  },
  infoLayers: { // these are layerOptions that share a function or are layers that are grouped in the mapfile/dlegend or are not in the mapfile/dlegend (parent info)
    parent: (records) => { // Using parent selection set - Don't push history, needs to be here because it is not in mapfile/dlegend
      const count = rwg.selection.parent.update(records);
      if (count) {
        rwg.filter = null
        return rwg.selection.parent.render(null,
          `<div class = "align-left-right"><div>${count} Parent Parcel(s)</div><a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel(s)</a>`
        );
      }
    },
  },
  initCode: {}
};
