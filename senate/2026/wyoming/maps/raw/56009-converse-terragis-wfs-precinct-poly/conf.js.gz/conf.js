document.title = 'Converse County, Wyoming';
const rwgInitParams = {
  utm_zone: "13",
  statePlane: 'EPSG:3736',
  olProjection: { code: 'EPSG:3736', units: 'us-ft' },
  olView: {
    extent: [410000, 650000, 735000, 1095000],
    minResolution: 0.2,
    maxResolution: 900,
  },
  mapfile: 'MAP13',
  mapserv: '/cgi-bin/mapserv76.fcgi',
  defaultImgTyp: 'png8g',
  otherMaps: {
    'Pictometry': {active: false},
    'Pictometry Explorer': {active: location.pathname.includes('picto')},
    'Google': { active: true},
    'Bing': { active: true},
    'Google Earth': {active: true}
  },
  sources: {
    a24: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTCO24-Grb25RfoqM',
    },	  
    a22: {
      type: 'WMTS',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTCO22-RiR1j30jKX', // Capture dates: 09/11/2022 - 11/24/2022
      projection: 'EPSG:3857',
    },
  },
  styles: {
  },
  olLayers: [
    { name: 'a2024',
      source: 'a24',
      // extent: [], // extent should be epsg:3739 despite the source being epsg:3857
    }
  ],
  layerOptions: {
    a2024: {
      // imgType: 'jpeg', // using Eagleview WMTS 
      info: () => {}
    },
    a22: {imgType: 'jpeg'},
    a20: {imgType: 'jpeg'},
    a19: {imgType: 'jpeg'},
    a17: {imgType: 'jpeg'},
    a15: {imgType: 'jpeg'},
    a14: {imgType: 'jpeg'},
    a11: {imgType: 'jpeg'},
    a09: {imgType: 'jpeg'},
    a06: {imgType: 'jpeg'},
    a01: {imgType: 'jpeg'},
    a95: {imgType: 'jpeg'},
    drg: {imgType: 'jpeg'},
    wellheads: { info: records => {
      var count = rwg.selection.wellheads.update(records);
      if (count) {
        return rwg.selection.wellheads.render(null, count + ' Wellhead(s)');
      }
    }},
    ownership: {
      info: records => {
        var count = rwg.selection.ownership.update(records);
        if (count) {
          rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
          rwg.historyManager.push();
          return rwg.selection.ownership.render(
            null,
            '<table style="width: 100%"><tr><td>' + count +
            ' Parcel(s)</td> <td style="text-align:right"><a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel(s)</a></td></tr></table>'
          );
        } else {
          rwg.filter = '';
          rwg.historyManager.push();
        }
      }
    },
    precinct: {
      info: records => rwg.formatInfo(
        records,
        [
          ['Precinct'] /* ,
          // for the General:
          [false, dat => return '<a href="//gwmap.s3.amazonaws.com/converse/ballots/general2018/' + dat + '.pdf" target="_blank"><b>Sample Ballot ' + dat + ' PDF</b></a>' ],
          ['State House District'],
          ['State Senate District'] */
        ],
        'Voter Precinct'
      )
    },
    cemetery: {
      info: records => rwg.formatInfo(records,[
        ['noLabel'],['noLabel'],['noLabel'],
        [false, dat => rwg.mapFeatures(dat)]
      ])
    }
  },
  navbar: {
    jump2s: [
      {'Converse County': [410000, 650000, 735000, 1095000]},
      {'Douglas': [548185, 800580, 647618, 842219]},
      {'Esterbrook': [582582, 687476, 610602, 707954]},
      {'Glenrock': [455000, 845000, 491000, 871000]},
      {'Lost Springs': [700700, 815200, 739400, 833150]},
      {'Rolling Hills': [459000, 866140, 497000, 885150]}
    ],
  },
  disclaimer: `ACCEPTANCE OF TERMS OF USE FOR THIS WEBSITE<P> This map/data is provided by Converse County, Wyoming and is for display purposes only. Converse County invokes its sovereign and governmental immunity in allowing access to or use of this data, and makes no warranties as to the validity, and assumes no liability associated with the use or misuse of this information.`,
  print: {
    "template_path": "shared_templates",
    "title": "Converse County Wyoming MapServer",
    "disclaimer": "This map is provided by Converse County for display purposes only. Converse County invokes its sovereign and governmental immunity in allowing access to or use of this data, and makes no warranties as to the validity, and assumes no liability associated with the use or misuse of this information."
  },
  selectionSets: {
    ownership:  [
      ['Parcel'],
      ['Account#', dat => '<a href="javascript:rwg.detailTab(\'' + dat + '\')" >Property Detail</a>'],
      ['Tax ID', dat => '&nbsp;<A href="https://itax.tylertech.com/ConverseWY/detail.aspx?taxid=' + dat + '" target=_blank>Property Taxes</A>'],
      ['Plat'],['Lot'],
      ['Owner'], ['Common Name'],['Mail Addr'],['Mail Addr'],
      ['St Addr'],
      ['Deed'],['Location'],
      ['Tax Classification'],
      ['Acres'],['Sq Ft'],
      [false, dat => {if (! location.pathname.includes('assessor')) rwg.mapFeatures(dat)}], //removes address point label on assmap per Dixie's request
      [false, dat => rwg.mapFeatures(dat)],
      ['Acres calc'],['LEA'],['Neighborhood'],['Value Measure'],['Quality'],['Condition'],['Effective Age']
    ],
    wellheads:[
      ['Well API Number'], ['Class'], ['Operator'], ['Well Name'], ['Bottom Hole'], ['Elevation GR'],['Elevation KB'],
      ['Total Depth'], ['Plug Back'], ['Target Formation'], ['Coal Bed'], ['Status'], ['Location']
    ]
  },
  initCode: {
    // non jq-ui-tabs
    cemeterySearch: () => {
      rwg.tabs.add({
        group_tab: 'srch-cemetery',
        button_text: 'Cemetery Search',
        tab_innerHTML: `
          <div><b>Search cemetery plots</b></div>
          <p>Search by Last Name. Names are not case sensitive.</p>
          <form class="searchForm" action="tabList.php">
            <input type="text" name="cemetery_name" placeholder="search for name">
            <input type="submit" value="search">
          </form>`,
        tab_classList: 'searchType',
      });

      if (rwg.args?.tab === 'cemetery') {
        rwg.tabs.activate('top-search'); // switch to the search tab
        rwg.tabs.activate('srch-cemetery'); // switch to cemetery tab within the search tab
      }

      rwg.plotMapIt = filter => {  // for cemetery search
        rwg.renderInfo(rwg.config.info_url + 'layers=cemetery&filter=' + filter, true);
        rwg.tabs.activate('top-map');
        rwg.layers.addLayers('cemetery');
      };

    },
    /*
    cemeterySearch: function() { // jq-ui-tabs
      let newTab = rwg.tabs.add({
        group_tab: 'srch-cemetery',
        button_text: 'Cemetery Search',
        classList: 'searchType',
        tab_innerHTML: `
          <div><b>Search cemetery plots</b></div>
          <p>Search by Last Name. Names are not case sensitive.</p>
          <form name="cemeterySearch" id="cemeterySearch" class="searchForm" action="tabList.php">
            <input type="text" name="cemetery_name" placeholder="search for name">
            <input type="submit" value="search">
          </form>`
      })
      // document.querySelector('div[data-search-div]').insertBefore(newTab, document.querySelector('#search_results'));
      document.querySelector('div[rwg-tab="srch-adv"]').insertAdjacentElement('afterend', newTab);
      if (rwg.args.tab && rwg.args.tab === 'cemetery') {
        $('#mapTabs').tabs('option', 'active', 1); // switch to jQuery search tab
        rwg.tabs.activate('srch-cemetery'); // switch to cemetery tab within the search tab
      }
      rwg.plotMapIt = function(filter) {  // for cemetery search
        rwg.renderInfo(rwg.config.info_url + 'layers=cemetery&filter=' + filter, true);
        $('#mapTabs').tabs("option","active", 0); // switch to map tab
        // legend.check('cemetery');
        rwg.layers.addLayers('cemetery');
      }
    }
    * */
  }
}
