Wyoming 2024 General Election Precinct-Level Results and Boundaries

## RDH Date Retrieval
4/28/26

## Sources
Wyoming Secretary of State (https://sos.wyo.gov/elections/electionresults.aspx)

Precinct boundaries from a variety of sources:
Albany: County GIS
Big Horn: Census VTD
Campbell: County GIS, matched boundaries approved April 2024 file
Carbon: Terra GIS
Converse: Terra GIS
Crook: Census VTD, edited to match map retrieved through contact
Fremont: Terra GIS
Goshen: Census VTD, edited to match map
Hot Springs: Terra GIS
Johnson: Census VTD
Laramie: County GIS, aligned to 2024 precinct map and municipal boundaries
Lincoln: County GIS
Natrona: County GIS
Niobrara: Census VTD
Park: Terra GIS
Platte: Terra GIS
Sheridan: Terra GIS
Sublette: Census VTD
Sweetwater: Terra GIS
Teton: Terra GIS
Uinta: Terra GIS
Washakie: Census VTD
Weston: County GIS

Precinct boundaries were checked against precinct assignments in a state voter file from L2, dated March 6, 2025.

## Notes on Field Names:
Columns reporting votes generally follow the pattern:
One example is:
GPREDCLI
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes Used:
A# - Constitutional Amendment
PRE - President of the United States
USS - U.S. Senate
CONAL - U.S. Congress (At-Large)
SL## - State Representative (State Legislative Lower)
SU## - State Senator (State Legislative Upper)
SPMXX - Supreme Court Justice

Party Codes Used:
C - Constitution
D - Democrat
I - Independent
L - Libertarian
O - Other / Write-Ins
R - Republican

## Fields:
Field Name Description                                                                               
UNIQUE_ID  Unique ID for each precinct                                                               
COUNTYFP   County FIP identifier                                                                     
County     County Name                                                                               
Precinct   Precinct Name                                                                             
SLDL_DIST  State Representative District                                                             
SLDU_DIST  State Senate District                                                                     
G24A1AGA   Constitutional Amendment A Separate Residential Property Class for Tax Assessment, Against
G24A1FOR   Constitutional Amendment A Separate Residential Property Class for Tax Assessment, For    
G24PREDHAR United States President, Kamala D. Harris and Tim Walz (D)                                
G24PRELOLI United States President, Chase Oliver and Mike ter Maat (L)                               
G24PREOWRI United States President, Write-Ins                                                        
G24PRERTRU United States President, Donald J. Trump and JD Vance (R)                                 
G24USSDMOR United States Senator, Scott D Morrow (D)                                                 
G24USSOWRI United States Senator, Write-Ins                                                          
G24USSRBAR United States Senator, John Barrasso (R)                                                  
GCONALCHAG United States Representative, Jeffrey Haggit (C)                                          
GCONALDCAM United States Representative, Kyle G. Cameron (D)                                         
GCONALLBRU United States Representative, Richard Brubaker (L)                                        
GCONALOWRI United States Representative, Write-Ins                                                   
GCONALRHAG United States Representative, Harriet Hageman (R)                                         
GSL01OWRI  House District 1, Write-Ins                                                               
GSL01RNEI  House District 1, Chip Neiman (R)                                                         
GSL02OWRI  House District 2, Write-Ins                                                               
GSL02RWIL  House District 2, JD Williams (R)                                                         
GSL03OWRI  House District 3, Write-Ins                                                               
GSL03RANG  House District 3, Abby Angelos (R)                                                        
GSL04DRAN  House District 4, Charles Randolph (D)                                                    
GSL04OWRI  House District 4, Write-Ins                                                               
GSL04RHAR  House District 4, Jeremy Haroldson (R)                                                    
GSL05OWRI  House District 5, Write-Ins                                                               
GSL05RSMI  House District 5, Scott Smith (R)                                                         
GSL06OWRI  House District 6, Write-Ins                                                               
GSL06RSTR  House District 6, Tomi Strock (R)                                                         
GSL07DEVA  House District 7, Jordan Evans (D)                                                        
GSL07OWRI  House District 7, Write-Ins                                                               
GSL07RNIC  House District 7, Bob Nicholas (R)                                                        
GSL08OWRI  House District 8, Write-Ins                                                               
GSL08RJOH  House District 8, Steve Johnson (R)                                                       
GSL09OWRI  House District 9, Write-Ins                                                               
GSL09RBRO  House District 9, Landon J. Brown (R)                                                     
GSL10IFOR  House District 10, Timothy (Tim) Forbis (I)                                               
GSL10OWRI  House District 10, Write-Ins                                                              
GSL10REKL  House District 10, John Eklund (R)                                                        
GSL11DBUR  House District 11, Sara Burlingame (D)                                                    
GSL11OWRI  House District 11, Write-Ins                                                              
GSL11RWAS  House District 11, Jacob Wasserburger (R)                                                 
GSL12OWRI  House District 12, Write-Ins                                                              
GSL12RSTY  House District 12, Clarence Styvar (R)                                                    
GSL13DCHE  House District 13, Ken Chestek (D)                                                        
GSL13OWRI  House District 13, Write-Ins                                                              
GSL13RSWE  House District 13, Shane Swett (R)                                                        
GSL14DSHE  House District 14, Trey Sherwood (D)                                                      
GSL14OWRI  House District 14, Write-Ins                                                              
GSL14RGIU  House District 14, Joe Giustozzi (R)                                                      
GSL15OWRI  House District 15, Write-Ins                                                              
GSL15RTHA  House District 15, Pamela Thayer (R)                                                      
GSL16DYIN  House District 16, Mike Yin (D)                                                           
GSL16OWRI  House District 16, Write-Ins                                                              
GSL17OWRI  House District 17, Write-Ins                                                              
GSL17RLAR  House District 17, J.T. Larson (R)                                                        
GSL18OWRI  House District 18, Write-Ins                                                              
GSL18RHEI  House District 18, Scott Heiner (R)                                                       
GSL19OWRI  House District 19, Write-Ins                                                              
GSL19RWEB  House District 19, Joe Webb (R)                                                           
GSL20OWRI  House District 20, Write-Ins                                                              
GSL20RSCH  House District 20, Mike Schmid (R)                                                        
GSL21OWRI  House District 21, Write-Ins                                                              
GSL21RERI  House District 21, McKay L. Erickson (R)                                                  
GSL22OWRI  House District 22, Write-Ins                                                              
GSL22RBYR  House District 22, Andrew P Byron (R)                                                     
GSL23DSTO  House District 23, Liz Storer (D)                                                         
GSL23OWRI  House District 23, Write-Ins                                                              
GSL24OWRI  House District 24, Write-Ins                                                              
GSL24RWEB  House District 24, Nina Webber (R)                                                        
GSL25OWRI  House District 25, Write-Ins                                                              
GSL25RHOE  House District 25, Paul Hoeft (R)                                                         
GSL26OWRI  House District 26, Write-Ins                                                              
GSL26RBAN  House District 26, Dalton Banks (R)                                                       
GSL27OWRI  House District 27, Write-Ins                                                              
GSL27RLAW  House District 27, Martha Lawley (R)                                                      
GSL28DALW  House District 28, Larry Alwin (D)                                                        
GSL28OWRI  House District 28, Write-Ins                                                              
GSL28RWIN  House District 28, John R. Winter (R)                                                     
GSL29DWRI  House District 29, Martha J Wright (D)                                                    
GSL29OWRI  House District 29, Write-Ins                                                              
GSL29RPEN  House District 29, Ken Pendergraft (R)                                                    
GSL30OWRI  House District 30, Write-Ins                                                              
GSL30RKEL  House District 30, Tom Kelly (R)                                                          
GSL31OWRI  House District 31, Write-Ins                                                              
GSL31RBEA  House District 31, John W Bear (R)                                                        
GSL32OWRI  House District 32, Write-Ins                                                              
GSL32RCLO  House District 32, Ken L. Clouston (R)                                                    
GSL33DPOS  House District 33, Ivan D. Posey (D)                                                      
GSL33OWRI  House District 33, Write-Ins                                                              
GSL33RPEN  House District 33, Sarah Penn (R)                                                         
GSL34OWRI  House District 34, Write-Ins                                                              
GSL34ROTT  House District 34, Pepper L. Ottman (R)                                                   
GSL35OWRI  House District 35, Write-Ins                                                              
GSL35RLOC  House District 35, Tony Locke (R)                                                         
GSL36OWRI  House District 36, Write-Ins                                                              
GSL36RWAS  House District 36, Art Washut (R)                                                         
GSL37OWRI  House District 37, Write-Ins                                                              
GSL37RHAR  House District 37, Steve Harshman (R)                                                     
GSL38OWRI  House District 38, Write-Ins                                                              
GSL38RLIE  House District 38, Jayme Lien (R)                                                         
GSL39OWRI  House District 39, Write-Ins                                                              
GSL39RWYL  House District 39, Cody Wylie (R)                                                         
GSL40OWRI  House District 40, Write-Ins                                                              
GSL40RCON  House District 40, Marilyn Connoly (R)                                                    
GSL41DSOL  House District 41, Jen Solis (D)                                                          
GSL41OWRI  House District 41, Write-Ins                                                              
GSL41RBRO  House District 41, Gary Brown (R)                                                         
GSL42DRAY  House District 42, Bob Ray (D)                                                            
GSL42OWRI  House District 42, Write-Ins                                                              
GSL42RGER  House District 42, Rob Geringer (R)                                                       
GSL43OWRI  House District 43, Write-Ins                                                              
GSL43RLUC  House District 43, Ann Lucas (R)                                                          
GSL44OWRI  House District 44, Write-Ins                                                              
GSL44RFIL  House District 44, Lee Filer (R)                                                          
GSL45DPRO  House District 45, Karlee Provenza (D)                                                    
GSL45OWRI  House District 45, Write-Ins                                                              
GSL45RCRO  House District 45, Paul  Crouch (R)                                                       
GSL46DLOW  House District 46, Chris Lowry (D)                                                        
GSL46OWRI  House District 46, Write-Ins                                                              
GSL46RAND  House District 46, Ocean Andrew (R)                                                       
GSL47DWIL  House District 47, James A Wilson (D)                                                     
GSL47OWRI  House District 47, Write-Ins                                                              
GSL47RDAV  House District 47, Bob Davis (R)                                                          
GSL48OWRI  House District 48, Write-Ins                                                              
GSL48RMCC  House District 48, Darin M. McCann (R)                                                    
GSL49OWRI  House District 49, Write-Ins                                                              
GSL49RWHA  House District 49, Robert Wharff (R)                                                      
GSL50OWRI  House District 50, Write-Ins                                                              
GSL50RROD  House District 50, Rachel Rodriguez-Williams (R)                                          
GSL51OWRI  House District 51, Write-Ins                                                              
GSL51RBRA  House District 51, Laurie Bratten (R)                                                     
GSL52OWRI  House District 52, Write-Ins                                                              
GSL52RTAR  House District 52, Reuben Tarver (R)                                                      
GSL53OWRI  House District 53, Write-Ins                                                              
GSL53RKNA  House District 53, Christopher R. Knapp (R)                                               
GSL54OWRI  House District 54, Write-Ins                                                              
GSL54RLAR  House District 54, Lloyd Charles Larsen (R)                                               
GSL55OWRI  House District 55, Write-Ins                                                              
GSL55RGUG  House District 55, Joel Guggenmos (R)                                                     
GSL56OWRI  House District 56, Write-Ins                                                              
GSL56RCAM  House District 56, Elissa Campbell (R)                                                    
GSL57OWRI  House District 57, Write-Ins                                                              
GSL57RJAR  House District 57, Julie Jarvis (R)                                                       
GSL58OWRI  House District 58, Write-Ins                                                              
GSL58RALL  House District 58, Bill Allemand (R)                                                      
GSL59OWRI  House District 59, Write-Ins                                                              
GSL59RRIG  House District 59, J.R. Riggins (R)                                                       
GSL60DWHI  House District 60, Carmen Whitehead (D)                                                   
GSL60OWRI  House District 60, Write-Ins                                                              
GSL60RBRA  House District 60, Marlene Brady (R)                                                      
GSL61OWRI  House District 61, Write-Ins                                                              
GSL61RSIN  House District 61, Daniel J. Singh (R)                                                    
GSL62OWRI  House District 62, Write-Ins                                                              
GSL62RCAM  House District 62, Kevin Campbell (R)                                                     
GSPMFENO   Supreme Court Justice, Wyoming Supreme Court John G. Fenn, No                             
GSPMFEYES  Supreme Court Justice, Wyoming Supreme Court John G. Fenn, Yes                            
GSPMFONO   Supreme Court Justice, Wyoming Supreme Court Kate M. Fox, No                              
GSPMFOYES  Supreme Court Justice, Wyoming Supreme Court Kate M. Fox, Yes                             
GSU02OWRI  Senate District 2, Write-Ins                                                              
GSU02RBON  Senate District 2, Brian Boner (R)                                                        
GSU04OWRI  Senate District 4, Write-Ins                                                              
GSU04RNET  Senate District 4, Tara Nethercott (R)                                                    
GSU06OWRI  Senate District 6, Write-Ins                                                              
GSU06RSMI  Senate District 6, Darin Smith (R)                                                        
GSU08DHER  Senate District 8, Marguerite Herman (D)                                                  
GSU08OWRI  Senate District 8, Write-Ins                                                              
GSU08ROLS  Senate District 8, Jared Olsen (R)                                                        
GSU10DSEL  Senate District 10, Mike Selmer (D)                                                       
GSU10OWRI  Senate District 10, Write-Ins                                                             
GSU10RCRU  Senate District 10, Gary E Crum (R)                                                       
GSU12DZAN  Senate District 12, Kenilynn S Zanetti (D)                                                
GSU12OWRI  Senate District 12, Write-Ins                                                             
GSU12RKOL  Senate District 12, John K Kolb (R)                                                       
GSU14OWRI  Senate District 14, Write-Ins                                                             
GSU14RPEA  Senate District 14, Laura Taliaferro Pearson (R)                                          
GSU16OWRI  Senate District 16, Write-Ins                                                             
GSU16RDOC  Senate District 16, Dan Dockstader (R)                                                    
GSU18OWRI  Senate District 18, Write-Ins                                                             
GSU18RFRE  Senate District 18, Tim A. French (R)                                                     
GSU20OWRI  Senate District 20, Write-Ins                                                             
GSU20RCOO  Senate District 20, Ed Cooper (R)                                                         
GSU22OWRI  Senate District 22, Write-Ins                                                             
GSU22RCRA  Senate District 22, Barry Crago (R)                                                       
GSU24OWRI  Senate District 24, Write-Ins                                                             
GSU24RMCK  Senate District 24, Troy D McKeown (R)                                                    
GSU26OWRI  Senate District 26, Write-Ins                                                             
GSU26RSAL  Senate District 26, Tim Salazar (R)                                                       
GSU28OWRI  Senate District 28, Write-Ins                                                             
GSU28RAND  Senate District 28, Jim Anderson (R)                                                      
GSU30OWRI  Senate District 30, Write-Ins                                                             
GSU30RSCO  Senate District 30, Charles K. Scott (R)                                                  

## Processing Steps
Election results were compared against state-level totals and found to match in every instance. 

After joining the precincts to their boundaries, the files were checked for precinct-district splits. Ultimately, the precinct boundary and election result files are split across four different files. The "_all_" file contains all the election results joined to precinct boundaries, but does not account for the various precinct-district splits identified in processing and as such, does not contain district assignments. The "_sldl_", and "_sldu_" files contain State Representative and State Senate results at the most granular units for which data is available. Please note that in order to minimize superfluous splits, precinct splits are only made when a precinct contains votes for candidates in multiple districts, as such district assignments for precincts many not perfectly correspond to the districts themselves, particularly in large, uninhabited areas.

In a handful of cases, votes appear in contests in which no portion of the precinct is contained within the district. This occurred in 1 precinct (Uinta-:-2-1) in 1 State Legislative district.. As a result of this issue, 2 votes for "GSL49RWHA" were removed in this precinct and totals will not exactly match in the "_sldl_" version of the files. None of these votes are not removed from the "_all_" file.

Boundaries were run though MGGG's smart_repair function in the maup package (https://github.com/mggg/maup) prior to posting.

Please direct questions related to processing this dataset to info@redistrictingdatahub.org.
