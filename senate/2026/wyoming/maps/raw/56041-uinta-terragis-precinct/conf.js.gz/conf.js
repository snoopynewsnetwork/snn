document.title = 'Uinta County, Wyoming, MapServer';
const rwgInitParams = {
  hyphenatePIDN: function(n) {return n.substr(0,12);},  // chops off 2 trailing zeros
  utm_zone: '12',
  mapCoordSys: 'EPSG:3857',
  statePlane: 'EPSG:3739',
  dataCoordSys: 'EPSG:3739',
  geodesic: true,
  olView: {
    extent: [-12365140, 5007564, -12244111, 5099671],
    minZoom: 10, maxZoom: 21,
  },
  mapfile: 'MAP19',
  // mapserv: 'https://w5.gwmap.us/cgi-bin/mapserv76.fcgi',
  mapserv: '/w5/cgi-bin/mapserv76.fcgi',
  defaultImgTyp: 'png8g',
  fullDrawing: true,
  otherMaps: {
    'Google': {active: true},
    'Bing': {active: true},
    'Google Earth': {active: true},
    'Pictometry Explorer': {active: (location.pathname.indexOf('assessor') > -1)}
  },
  sources: {
    publand: { url: 'json-data/publand.topo.json' },
    zoning: {
      url: 'json-data/zoning.topo.json',
      loaded: s => s.getFeatures().forEach(f => rwg.styles.add(
        f.get('class'),
        {fill: {color: f.get('fillcolor')}, stroke: {color:'#000000', width:1}} // color here must be hex not rgb
      ))
    },
    precinct: { url: 'json-data/precinct.topo.json'},
    mask2023: { url: 'json-data/mask2023.topo.json' },
    a25: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts', // URL for TerraGIS including key
      layer: 'PICT-WYSTUI25-SLyWUXERdX', // this is differnent for each area
    },
    a23: {
      type: 'WMTS',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTUI23-pUqISw3Hko',
    },
    a20: {
      type: 'WMTS',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTUI20-Qrp7hjKhK2',
    },
  },
  styles: {
    S: {
      fill: {color: [255, 220, 208]},
      text: {
        font: '12pt Times New Roman, Times, serif',
        fill: {color: '#000000'},
        stroke: {color: '#ffffff', width: 2}, // halo
        text: 'State\nof\nWyoming',
      }
    },
    B: {
      fill: {color: [255, 255, 144]} ,
      text: {
        font: '12pt Times New Roman, Times, serif',
        fill: {color: '#000000'},
        stroke: {color: '#ffffff', width: 2}, // halo
        text: 'BLM',
        padding: [60, 60, 60, 60],
      }
    },
    /*subdiv: {
      fill: {color: [176, 96, 255]},
      stroke: { color: [0, 0, 128], width: 8 },
    },*/
    labelText: {
      text: {
        font: 'bold 12pt Arial, Helvetica, sans-serif', 
        fill: {color: '#000'},
        stroke: {color: 'white', width: 2},
      },
    },
    // precincts
    "1-1":   {fill: {color: [81,210,213,0.5] }},
    "1-2":   {fill: {color: [25,78,124,0.5]  }},
    "1-2-1": {fill: {color: [252,102,36,0.5] }},
    //"1-2-1": {fill: {color: [252,102,36,0.5] }},
    "1-3":   {fill: {color: [159,101,107,0.5]}},
    "1-3-1": {fill: {color: [33,177,87,0.5]  }},
    "1-3-2": {fill: {color: [48,96,184,0.5]  }},
    "1-4":   {fill: {color: [160,207,118,0.5]}},
    "2-1":   {fill: {color: [104,225,5,0.5]  }},
    "2-1-1": {fill: {color: [48,96,184,0.5]  }},
    "2-1-2": {fill: {color: [233,59,1,0.5]   }},
    "2-2":   {fill: {color: [170,192,143,0.5]}},
    "3-1":   {fill: {color: [136,27,110,0.5] }},
    //"3-1":   {fill: {color: [136,27,110,0.5] }},
    //"3-1":   {fill: {color: [136,27,110,0.5] }},
    "3-2":   {fill: {color: [255,255,127,0.5]}},
    //"3-2":   {fill: {color: [255,255,127,0.5]}},
    "4-1":   {fill: {color: [48,150,201,0.5] }},
    //"4-1":   {fill: {color: [48,150,201,0.5] }},
    "4-2":   {fill: {color: [83,202,56,0.5]  }},
    mask: { fill: {color: '#fff'} },
  },
  olLayers: [
    { type: "OSM", name: "osm" },
    /*{ type: 'BingMaps',
      source: {
        key: 'm336KAG2OIfHK790fB5q~1DtbEB91m7n9jbIozrGSpQ~Aj8__Nrpii0Er4GeffkovUi6a8oYlPqQIaV2yle307t1-4i1xOLiFpbZvvkexHPt',//'AkagYx-99lpfo4yl_V4-GlGBCJcXETu6H54P6GppgyACWC35y1re2AxdjkvoUTs5',
        imagerySet: 'Aerial',
        maxZoom: 19
      },
      name: 'aerialbing',
    },*/
    { type: 'XYZ',
      source: {
        url: 'https://atlas.microsoft.com/map/tile?api-version=2.1&tilesetId=microsoft.imagery&zoom={z}&x={x}&y={y}&subscription-key=VnVub64LDcCtlthxpaxBsKqpH7A0ieuCl4GMVaNki8SkGfyNAPg7JQQJ99BEAC8vTIn6JpxRAAAgAZMP1qtq',
        imagerySet: 'microsoft.imagery',
        maxZoom: 19
      },
      name: 'aerialbing',
    },
    { name: "topoesri",
      type: "XYZ",
      source: {
        attribution: 'Tiles © <a href="https://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer">ArcGIS</a>' ,
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
      },
    },
    /*
    { name: 'a23',
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'mask2023',
          style: () => rwg.styles.get('mask'),
          zIndex: 1,
        },
        { source: 'a23',
          extent: [-12368417,5013202,-12268300,5079282],
        },
      ]
    },
    { name: 'a20',
      source: 'a20',
      extent: [-12363536,5040029,-12276935,5074424]
    },
    */
    { name: 'background', type: 'ImageWMS'},
    { name: "publand",
      type: 'Vector',
      source: 'publand',
      style: feature => rwg.styles.get(feature.get('c')),
      opacity: 0.5,
    },
    { name: "zoning",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'zoning',
          opacity: 0.5,
          style: feature => rwg.styles.get(feature.get('class'))
        },
        { type: 'Vector',
          source: 'zoning',
          declutter: true,
          zIndex: 8,
          style: feature => {
            let geom = rwg.clipToExtent(feature, rwg.map)
            if (geom) {
              return rwg.styles.get('labelText', {
                text: {text: feature.get('class')},
                geom: geom
              })
            }
          },
        }
      ]
    },
    { name: "precinct",
      type: 'Vector',
      source: 'precinct',
      style: feature => {
        let precinct = feature.get('PRECINT')
        let style = [rwg.styles.get(precinct)]
        let geom
        geom = rwg.clipToExtent(feature, rwg.map)
        if (geom) {
          style.push(rwg.styles.get('labelText', {
            text: {text: precinct},
            geom: geom
          }))
        }
        return style
      },
      declutter: true,
      zIndex: 2,
    },
    { name: 'a2025',
      source: 'a25',
      // extent: [], // extent should be epsg:3739 despite the source being epsg:3857
    },	
  ],
  layerOptions: {
    a2025: {
      // imgType: 'jpeg', // using Eagleview WMTS 
      info: () => {}
    },	  
    a23: {imgType: 'jpeg', olLyr: "background"},
    a22: {imgType: 'jpeg', olLyr: "background"},
    a20: {imgType: 'jpeg', olLyr: "background"},
    a19: {imgType: 'jpeg', olLyr: "background"},
    a15: {imgType: 'jpeg', olLyr: "background"},
    a12: {imgType: 'jpeg', olLyr: "background"},
    drg: {imgType: 'jpeg', olLyr: "background"},
    wellheads: {info: records => rwg.formatInfo(records,[['Well API Number'],['Class'],['Operator'],['Well Name'],['Bottom Hole'],['Elevation GR'],['Elevation KB'],['Total Depth'],['Plug Back'],['Target Formation'],['Coal Bed'],['Status'],['Location']])},
    subdiv: {info: records => rwg.formatInfo(records,
        [[false, dat => {
          let i = dat.indexOf('$');
          if (i < 0) return dat;
          // return '<a href="https://gwmap.s3.amazonaws.com/uinta/plats/' +  dat.substring(i+1) + '" target="_blank">Scanned Map ' + dat.substring(0,i) + '</a>'
          // return '<a href="https://b2.gwmap.us/file/uinta-wy/plats/' +  dat.substring(i+1) + '" target="_blank">Scanned Map ' + dat.substring(0,i) + '</a>'
          return `<a href="https://uinta-wy.s3.us-west-002.backblazeb2.com/plats/${dat.substring(i+1)}" target="_blank">Scanned Map ${dat.substring(0,i)}</a>`
        }]
      ])
    },
    ownership: { info: records => {
      let count = rwg.selection.ownership.update(records);
      if (count > 0) {
        rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
        rwg.historyManager.push();
        return rwg.selection.ownership.render(
          null,
          '<table style="width: 100%"><tr><td>' + count +
          ' Parcel(s)</td><td style="text-align:right"><a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel(s)</a></td></tr></table>'
        );
      }
    }},
    rooflines: {info: records => rwg.formatInfo(records,
      [['Status'], ['area'], ['previous area'], ['percent change']],
      'Change Finder'
    )},
  },
  navbar: {
    jump2s: [
      {'Uinta County': [-12365140, 5007564, -12244111, 5099671]},
      {'Bear River': [-12361765, 5067161, -12356764, 5072654]},
      {'Evanston': [-12357644, 5045840, -12347979, 5054961]},
      {'Lyman': [-12282888, 5058820, -12273813, 5063041]},
      {'Mountain View': [-12284091, 5051463, -12280108, 5054309]}
    ]
  },
  disclaimer: `<p>ACCEPTANCE OF TERMS OF USE FOR THIS WEBSITE
  <p>This map/data is provided by Uinta County, Wyoming and is for display purposes only. Uinta County invokes its sovereign and governmental immunity in allowing access to or use of this data, and makes no warranties as to the validity or accuracy, and assumes no liability associated with the use or misuse of this information. The locations of property boundaries, easements, and other legal rights-of-way as shown shall be considered approximate and should be verified by a Wyoming Licensed Professional Land Surveyor.
  <p>Please contact the appropriate office for official current data or for any questions you may have concerning the data displayed on this map.`,
  print: {
    "title": "Uinta County Wyoming MapServer",
    "disclaimer": `This map is for display purposes only.
      Uinta County invokes its sovereign and governmental immunity in allowing use of this data,
      and makes no warranties as to the validity or accuracy,
      and assumes no liability associated with the use or misuse of this information.
      Locations are approximate`
  },
  selectionSets: {
    ownership: [
      ['Parcel'],
      ['Account', dat => '<a href="javascript:rwg.detailTab(\'' +  dat + '\')" >Property&nbsp;Detail</a>'],
      ['Plat'],['Lot'],
      ['Owner'],['Mail Add'],['Mail Add'],
      ['St Addr'],
      ['Deed'],['Location'],
      ['Tax Class'],['Area'],
      [false, dat => rwg.mapFeatures(dat)],
      [false, dat => rwg.mapFeatures(dat)],
      ['LEA'],['Neighborhood'],['Tax District'],['Value Measure'],['Quality'],['Condition']
    ]
  },
  initCode: {},
}
