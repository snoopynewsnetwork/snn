document.title = 'Carbon County, Wyoming, MapServer';

const isSaratogaTown = location.pathname.indexOf('saratogatown') > -1;

rwgInitParams = {
  utm_zone: "13",
  statePlane: "EPSG:3737",
  mapCoordSys: "EPSG:3857",
  dataCoordSys: "EPSG:3857",
  geodesic: true,
  olView: {
    extent: [-12015000, 5000000, -11806000, 5228000],
    minZoom: 9,
    maxZoom: 21,
  },
  geodesic: true,
  defaultImgTyp: 'png8g',
  mapserv: '/cgi-bin/mapserv76.fcgi',
  mapfile: 'MAP06',
  fullDrawing: true,
  otherMaps: {
    'Google': {active: true},
    'Bing': {active: true},
    'Google Earth': {active: true},
    'Pictometry Explorer': {active: (location.pathname.indexOf('assessor') > -1)}
  },
  sources: {
    lotnum: { url: 'json-data/lotnum.topo.json' },
    blocknum: { url: 'json-data/blocknum.topo.json' },
    stnum: { url: 'json-data/stnum.topo.json' },
    mask2023: { url: 'json-data/mask2023.geojson' },
    publand: { url: 'json-data/publand.topo.json' },
    precincts: {
      url: '/carbon/json-data/precincts2022.topo.json',
      loaded: (source) => {
        source.getFeatures().forEach(f => {
          let color = f.get('fillcolor').split(' ')
          color.push(0.5)  // opacity
          rwg.styles.add( f.get('name'),{fill: {color: color}} )
        })
      }
    },
    a20: {type: 'WMTS',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTCA20-lZj09SXnzE'
    },
    a23: {type: 'WMTS',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTCA23-asPgXo3b23'
    },
  },
  styles: {
    mask: { fill: {color: "#fff"} },
    S: { fill: {color: "#B7D8FA"} }, // State of Wyoming
    B: { fill: {color: "#FEDB98"} }, // BLM
    U: { fill: {color: [160, 255, 160]} }, // USFS
    C: { fill: {color: "#40476D"} }, // Carbon County
    labelText: {
      text: {
        font: 'bold 10pt Arial, Helvetica, sans-serif',
        fill: {color: '#000'},
        stroke: {color: 'white', width: 1},
      },
    },
    lotnum: {
      text: {
        font: '11pt Times New Roman, Times, serif',
        fill: {color: '#00f'},
        stroke: {color: '#fff', width: 2}, // halo
      }
    },
    blocknum: {
      text: {
        font: 'bold 14pt Times New Roman, Times, serif',
        fill: {color: '#00f'},
        stroke: {color: '#fff', width: 2}, // halo
      }
    },
    stnum: {
      text: {
        font: 'bold 10pt Arial, Helvetica, sans-serif',
        fill: {color: '#000'},
        stroke: {color: '#fff', width: 2}, // halo
      }
    },
  },
  olLayers: [
    { name: 'background', type: 'ImageWMS'},
    /*
    { name: 'a23',
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'mask2023',
          style: () => rwg.styles.get('mask'),
          zIndex: 1,
        },
        { source: 'a23',
          extent: [-1.1993e+07,5.00784e+06,-1.18138e+07,5.22464e+06],
        },
      ]
    },
    { name: 'a20',
      source: 'a20',
      extent: [-1.19875e+07,5.01396e+06,-1.18189e+07,5.14742e+06],
    },
    */
    { name: "osm", type: "OSM"},
    { name: "publand",
      type: 'Vector',
      source: 'publand',
      style: feature => rwg.styles.get(feature.get('c')),
      zIndex: 2,
      opacity: 0.5,
    },
/*  EG moved this to a conditional definition at the end of this file, so it will only be defined if we're not in the saratogatown map
    { name: "precincts",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'precincts',
          style: feature =>  rwg.styles.get(feature.get('name')),
          zIndex: 2,
        },
        { type: 'Vector',
          source: 'precincts',
          declutter: true,
          zIndex: 6,
          style: feature => rwg.styles.get('labelText', {
            text: {text: feature.get('name').replace(' ', '\n')},
            geom: rwg.pointInPolyInView(feature)
          })
        },
      ]
    },
*/
    { name: "lotnum",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'lotnum',
          style: feature => rwg.styles.get('lotnum', {text: {text: feature.get('n')}}),
          minZoom: 15,
          // zIndex: 7,
          declutter: true,
        },
        { type: 'Vector',
          source: 'blocknum',
          style: feature => rwg.styles.get('blocknum', {text: {text: feature.get('n')}}),
          minZoom: 15,
          // zIndex: 7,
          declutter: true,
        },
      ]
    },
    { name: "stnum",
      type: 'Vector',
      source: 'stnum',
      style: feature => rwg.styles.get('stnum', {text: {text: feature.get('n')}}),
      // minZoom: 15,
      // zIndex: 7,
      declutter: true,
    },
  ],
  layerOptions: {
    a23: {imgType: 'jpeg', olLyr: 'background'},
    a22: {imgType: 'jpeg', olLyr: 'background'},
    a20: {imgType: 'jpeg', olLyr: 'background'},
    a12: {imgType: 'jpeg', olLyr: 'background'},
    a17: {imgType: 'jpeg', olLyr: 'background'},
    a19: {imgType: 'jpeg', olLyr: 'background'},
    a15: {imgType: 'jpeg', olLyr: 'background'},
    a99: {imgType: 'jpeg', olLyr: 'background'},
    drg: {imgType: 'jpeg', olLyr: 'background'},
    wellheads: {info: function(records) {
      var count = rwg.selection.wellheads.update(records);
      if (count) {
        return rwg.selection.wellheads.render(null, count + ' Wellhead(s)');
      }
    }},
    ownership: {info: function(records) {
      var count = rwg.selection.ownership.update(records);
      if (count) {
        rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
        rwg.historyManager.push();
        return rwg.selection.ownership.render( null,
          '<table style="width: 100%"><tr><td>' + count +
          ' Parcel(s)</td><td style="text-align:right"><a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel(s)</a></td></tr></table>'
        );
      } else {
        rwg.filter = '';
        rwg.historyManager.push();
      }
    }},
    rooflines: {info: records => rwg.formatInfo(records,
      [['Status'], ['area'], ['previous area'], ['percent change']],
      'Change Finder'
    )},
  },
  navbar: {
    jump2s: [
      {'Carbon County': [-12015000, 5000000, -11806000, 5228000]},
      {'Baggs/Dixon': [-11989241, 5012789, -11968985, 5027239]},
      {'Elk Mountain': [-11852015, 5110388, -11839928, 5119140]},
      {'Encampment/Riverside': [-11889848, 5041196, -11885906, 5045267]},
      {'Hanna/Medicine Bow': [-11865076, 5128965, -11819099, 5157556]},
      {'Muddy Gap':       [-11968223, 5207329, -11951292, 5224833]},
      {'Rawlins/Sinclair': [-11942111, 5117899, -11921641, 5139015]},
      {'Saratoga': [-11892300, 5076933, -11888176, 5081200]}
    ]
  },
  print: {
    "title": "Carbon County, Wyoming",
    'disclaimer': `This data has been prepared from the best records available to Carbon County.
      It is presented “AS IS” and there is no express or implied warranty of any kind by Carbon County
      or Terra GIS Ltd. for completeness, accuracy, currency or correctness of this information,
      including, but not limited to, warranties of title, merchantability, satisfactory quality or fitness
      for a particular purpose. This data is not necessarily accurate by surveying standards, and is not
      to be used for legal conveyance. Carbon County nor Terra GIS Ltd. shall not be liable for
      damages of any kind arising out of use of this product or for any errors or inaccuracies.`
  },
  selectionSets: {
    ownership: [
      ['PIDN'],
      ['Account',  function (dat) { return '<a href="javascript:rwg.detailTab(\'' +  dat + '\')" >Property&nbsp;Detail</a>' } ],
      ['Tax ID',   function (dat) { return '&nbsp;<a href="https://itax.tylertech.com/CarbonWY/detail.aspx?taxid=' + dat + '" target=_blank>Property Taxes</a>'} ],
      ['Lot'],
      ['Name'],['Mail Addr'],['Mail Addr'],
      ['St Addr'],
      ['Deed'],['Location'],
      ['Net Acres'],['Type'],
      [false, function(dat) { rwg.mapFeatures(dat); return '';}],
      [false, function(dat) { rwg.mapFeatures(dat); return '';}],
      ['LEA'],['Neighborhood'],['Tax District'],['Value Measure'],['Quality'],['Condition'],['Last Appraisal Year'],['Detailed Review Date']
    ],
    wellheads: [
      ['Well API Number'], ['Class'], ['Operator'], ['Well Name'], ['Bottom Hole'], ['Elevation GR'],['Elevation KB'],
      ['Total Depth'], ['Plug Back'], ['Target Formation'], ['Coal Bed'], ['Status'], ['Location']
    ],
  },
  advancedSearch: false,
  initCode: {
    hideAdvancedSearch: function() {  // no advanced search
      var element = document.getElementById('showMore') || document.getElementById('search-tabs');
      if (element) {
        element.style.display = 'none';
      }
    },
    hidePubland: () => {
       if (location.pathname.indexOf('saratogatown') > -1) {
          rwg.map.getLayerByTitle('publand').setVisible(false)
          // rwg.map.getLayerByTitle('precincts').setVisible(false)		 
       }
    }
  }
};

if (location.pathname.indexOf('saratogatown') < 0) {
  rwgInitParams.olLayers.push(
    { name: "precincts",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'precincts',
          style: feature =>  rwg.styles.get(feature.get('name')),
          zIndex: 2,
        },
        { type: 'Vector',
          source: 'precincts',
          declutter: true,
          zIndex: 6,
          style: feature => rwg.styles.get('labelText', {
            text: {text: feature.get('name').replace(' ', '\n')},
            geom: rwg.pointInPolyInView(feature)
          })
        },
      ]
    }
  );
}

// Basemaps nur, wenn nicht Saratoga-Town
if (!isSaratogaTown) {
  rwgInitParams.olLayers.unshift(
    {
      name: "mapbox",
      type: "XYZ",
      source: {
        url: 'https://api.mapbox.com/v4/mapbox.satellite/{z}/{x}/{y}.png?access_token=pk.eyJ1Ijoia2Fyc3RlbnZlbm5lbWFubiIsImEiOiJjbWU1b2RnazYwODA4MmxzOGl2Nm1vOTN5In0.LrJg9dJKTHtHqYs0kO8dbg',
        maxZoom: 18
      }
    },
    {
      name: 'opentopo',
      type: "XYZ",
      source: { url: 'https://{a-c}.tile.opentopomap.org/{z}/{x}/{y}.png' }
    }
  );
}
