document.title = 'Sheridan County, Wyoming, MapServer';

// GWM-BALLOTS begin: the sample ballot links of the precincts layer. Switch with gwm-ballots (share/gwm_maptools)
// or on the status page (Map Configuration, Ballots), not by hand.
const gwmBallots = {
  "mode": "general",
  "general": {
    "base": "https://sheridan-wy.s3.us-west-002.backblazeb2.com/ballots/",
    "file": "{precinct}.pdf",
    "label": "Sample Ballot"
  },
  "primary": [
    {
      "base": "https://sheridan-wy.s3.us-west-002.backblazeb2.com/ballots/",
      "file": "{precinct}-D.pdf",
      "label": "Democratic Party"
    },
    {
      "base": "https://sheridan-wy.s3.us-west-002.backblazeb2.com/ballots/",
      "file": "{precinct}-NP.pdf",
      "label": "Non Partisan"
    },
    {
      "base": "https://sheridan-wy.s3.us-west-002.backblazeb2.com/ballots/",
      "file": "{precinct}-R.pdf",
      "label": "Republican Party"
    }
  ],
  "precincts": {
    "sql": "select distinct ballot from electionunion"
  }
};
function gwmBallotLinks(dat) {
  // the sample ballot links of one precinct, from gwmBallots (written by gwm-ballots)
  const b = gwmBallots;
  const url = (m) => m.base + m.file.split('{precinct}').join(dat);
  const text = (s) => s.split('{precinct}').join(dat);
  if (b.mode === 'general') {
    return `<a href="${url(b.general)}" target="_blank"><b>${text(b.general.label)}</b></a>`;
  }
  if (b.mode === 'primary') {
    return 'Sample Ballots:<div style="margin-left: 1em;">'
      + b.primary.map((p) => `<a href="${url(p)}" target="_blank">${text(p.label)}</a>`).join('<br>') + '</div>';
  }
  return '';
}
// GWM-BALLOTS end

rwgInitParams = {
  // mapserv: 'https://w5.gwmap.us/cgi-bin/mapserv76.fcgi',
  mapserv: '/w5/cgi-bin/mapserv76.fcgi',
  utm_zone: '13',
  mapCoordSys: 'EPSG:3857',
  statePlane: 'EPSG:3737',
  dataCoordSys: 'EPSG:3857',
  geodesic: true,
  olView: {
    extent: [-12015000, 5546000, -11800000, 5624000],
    minZoom: 10, maxZoom: 21,
  },
  mapfile: 'MAP03',
  defaultImgTyp: 'png8g',
  otherMaps: {
    'Google': {active: true},
    'Bing': {active: true},
    'Google Earth': {active: true},
    'Pictometry Explorer': {active: (location.pathname.indexOf('assessor') > -1)}
  },
  propTaxLink: 'https://itax.tylertech.com/sheridanwy/detail.aspx?taxid=',
  sources: {
    lotnumbers: { url: 'json-data/lotnumbers.topo.json' },
    streetnum: { url: 'json-data/streetnum.topo.json' },
    mask2007: { url: 'json-data/mask-2007-city.geojson' },
    mask2017: { url: 'json-data/mask-2017.geojson' },
    publand: { url: 'json-data/publand.topo.json' },
    corplimits: { url: 'json-data/corplimits.topo.json' },
    corplables: { url: 'json-data/corplables.topo.json' },
    roads: { url: 'json-data/roads.topo.json' },
    railroads: { url: 'json-data/railroads.topo.json' },
    shields: { url: 'json-data/hwy-num.topo.json' },
    legislature: {url: 'json-data/legislature.topo.json'},
    senateHouseClipRWG: {url: 'json-data/senateHouseClipRWG.topo.json',},
    precincts: {
      url: 'json-data/precincts.topo.json',
      loaded: s => s.getFeatures().forEach(f =>
        rwg.styles.add( f.get('class'),
          {fill: {color: f.get('fillcolor') + '90'}} ) // color is hex, add opacity
      )
    },
    a25: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts', // URL for TerraGIS including key
      layer: 'PICT-WYSTSH00-CKMYA6rhw8', // this is differnent for each area
    },a23: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTSJ23-pGsnttfoy2',
    },
    a20: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTSJ20-G4TOIn9qvA',
    },
  },
  styles: {
    mask: { fill: {color: [255, 255, 255]} },
    WYSL: { fill: {color: "#B7D8FA77"} }, // Wyoming State Land
    BLM: { fill: {color: "#FEDB9877"} },
    USFS: { fill: {color: "#A0FFA077"} },
    OFL: { fill: {color: "#F8F29A77"} }, // Other FEDERAL LAND
    LG: { fill: {color: "#40476D77"} }, // local gov
    DOD: { fill: {color: "#FFDCD077"} }, //  DEPARTMENT OF DEFENSE
    labelText: {
      text: {
        font: 'bold 12pt Arial, Helvetica, sans-serif',
        fill: {color: '#000'},
        stroke: {color: 'white', width: 2},
      },
    },
    corpText: {
      text: {
        font: 'bold 14pt Arial, Helvetica, sans-serif',
        fill: {color: '#000'},
        stroke: {color: 'white', width: 2},
        overflow: true
      },
    },
    corplimits: {
      stroke: {color: '#85000088', width: 6},
    },
    roadShadow: {
      stroke: {
        color: '#555555',
        width: 3,
      },
      zIndex: 0,
    },
    roadLine: {
      stroke: {
        lineJoin: 'miter',
      },
      zIndex: 1,
    },
    rr_tie: {
      stroke: {
        color: '#888',
        width: 5,
        lineDash: [1,15],
        lineCap: 'butt',
      },
      zIndex: 1,
    },
    rr_line: {
      stroke: { color: '#888', width: 1 },
      zIndex: 2,
    },
    roadLabel: {
      text: {
        placement: 'line',
        maxAngle: Math.PI / 12,
        font: 'bold 12px Arial',
        fill: {color: 'black'},
        stroke: {color: 'white', width: 1},  // do NOT quote the width!
        // offsetY: -8,
      },
      zIndex: 2,
    },
    shieldInterstate: {
      xy: [],
      icon: {
        src: '/mapserver/interstate.png',
        scale: 0.9
      },
      text: {
        placement: 'point',
        font: 'bold 12px Arial',
        fill: {color: '#ffffff'},
        text: '90'
      },
      zIndex: 1,
    },
    shieldUS2: { // tall for stacked numbers
      xy: [],
      icon: {
        // src: '/mapserver/ushwy2.png',
        src: '/mapserver/ushwy.png',
        scale: [0.9, 1.2]
      },
      text: {
        placement: 'point',
        font: 'bold 12px Arial',
      },
      zIndex: 1,
    },
    shieldUS: {
      xy: [],
      icon: {
        src: '/mapserver/ushwy.png',
        scale: 0.7
      },
      text: {
        font: 'bold 12px Arial',
        offsetY: 1,
      },
      zIndex: 1,
    },
    shieldWY: {
      xy: [],
      icon: {
        src: '/mapserver/wyhwy.png',
        scale: 0.7,
      },
      text: {
        placement: 'point',
        offsetY: 2,
        font: 'bold 10px Arial',
      },
      zIndex: 1,
    },
    polyfilled: {
      fill: {color: '#fff'}
    },
    streetnum: {
      text: {
        font: '11pt Arial, Helvetica, sans-serif',
        stroke: {color: 'white', width: 2}, // halo
      },
    },
    lotnumbers: {
      text: {
        font: '13pt Times New Roman, Times, serif',
        fill: {color: '#0000ff'},
        stroke: {color: '#ffffff', width: 2}, // halo
      }
    },
  },
  olLayers: [
    { name: 'opentopo',
      type: "XYZ",
      source: {
        url: 'https://a.tile.opentopomap.org/{z}/{x}/{y}.png' // 'https://{a|b|c}.tile.opentopomap.org/{z}/{x}/{y}.png',
      }
    },
    { type: "OSM", name: "osm" },
    { name: 'background', type: 'ImageWMS'},
    { name: 'a2025',
      source: 'a25',
      // extent: [], // extent should be epsg:3739 despite the source being epsg:3857
    },
    { name: 'a23',
      source: 'a23',
      extent: [-11951311.018183, 5547800, -11852555.456335, 5623319.2968402],
    },
    { name: 'a20',
      source: 'a20',
      extent: [-11951081.707045, 5547800, -11882748.082554, 5622784.237683],
    },
    { name: "senatehouse2022",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'senateHouseClipRWG',
          style: feature => {
            const color = {
              'HD 29, SD 21': '#4918e977',
              'HD 29, SD 22': '#efc26f77',
              'HD 30, SD 21': '#48f06777',
              'HD 30, SD 22': '#6bd9dc77',
              'HD 40, SD 21': '#F4DA1777',
              'HD 40, SD 22': '#8b90eb77',
              'HD 51, SD 21': '#CB5B5B77',
            }
            let dist = feature.get('DISTRICT')
            return rwg.styles.get('polyfilled', {fill:{color:color[dist]}})
          },
        },
        { type: 'Vector',
          source: 'senateHouseClipRWG',
          zIndex: 8,
          declutter: true,
          /*
          style: feature => {
            let geom = rwg.clipToExtent(feature, rwg.map)
            if (geom) {
              let dist = feature.get('DISTRICT')
              return rwg.styles.get('labelText', {
                text: {text: dist.replace(', ', '\n')},
                geom: geom
              })
            }
          },
          */
          style:  feature => rwg.styles.get('labelText', {
            text: {text: feature.get('DISTRICT').replace(', ', '\n')},
            geom: rwg.pointInPolyInView(feature)
          })
        }
      ]
    },
    { name: "senate2022",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'legislature', // 'sd2022',
          style: feature => {
            const colors = {
              '21': '#24ce1b77',
              '22': '#8b90eb77',
            }
            let dist = feature.get('district')
            let c = colors[dist]
            if (c) {  // house & senate in same file so only return style if in colors
              return rwg.styles.get('polyfilled', {fill:{color:c}})
            }
          },
        },
        { type: 'Vector',
          source: 'legislature', // 'sd2022',
          declutter: true,
          zIndex: 8,
          style: feature => {
            let dist = feature.get('district')
            if ([21, 22].includes(parseInt(dist))) { // house & senate in same file so check dist
              /*
              let geom
              geom = rwg.clipToExtent(feature, rwg.map)
              if (geom) {
                return rwg.styles.get('labelText', {
                  text: {text: 'SD '+ dist},
                  geom: geom
                })
              }
              */
              return rwg.styles.get('labelText', {
                text: {text: 'SD '+ dist},
                geom: rwg.pointInPolyInView(feature)
              })
            }
          },
        }
      ]
    },
    { name: "house2022",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'legislature', // source: 'hd2022',
          style: feature => {
            const colors = {
              '29': '#4918e977',
              '30': '#efc26f77',
              '40': '#48f06777',
              '51': '#6bd9dc77',
            }
            let dist = feature.get('district')
            let c = colors[dist]
            if (c) {  // house & senate in same file so only return style if in colors
              return rwg.styles.get('polyfilled', {fill:{color:c}})
            }
          },
        },
        { type: 'Vector',
          source: 'legislature', // source: 'hd2022',
          declutter: true,
          zIndex: 8,
          style: feature => {
            let dist = feature.get('district')
            if ([29,30,40,51].includes(parseInt(dist))) {  // house & senate in same file so only return style if house districts array
              let geom
              geom = rwg.clipToExtent(feature, rwg.map)
              if (geom) {
                return rwg.styles.get('labelText', {
                  text: {text: 'HD '+ dist},
                  geom: geom
                })
              }
            }
          },
        }
      ]
    },
    { name: "precincts",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'precincts',
          style: feature => rwg.styles.get(feature.get('class'))
        },
        { type: 'Vector',
          source: 'precincts',
          declutter: true,
          zIndex: 8,
          style: feature => {
            let geom = rwg.clipToExtent(feature, rwg.map)
            if (geom) {
              return rwg.styles.get('labelText', {
                text: {text: feature.get('class')},
                geom: geom,
              })
            }
          },
        }
      ]
    },
    { name: "publand",
      type: 'Vector',
      source: 'publand',
      style: feature => rwg.styles.get(feature.get('c')),
    },
    { name: "corplimits",
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'corplimits',
          style: () => rwg.styles.get('corplimits'),
          zIndex: 2,
        },
        { type: 'Vector',
          source: 'corplables',
          style: feature => rwg.styles.get('corpText', {
            text: {text: feature.get('City').replaceAll(' ','\n')}
          }),
          zIndex: 8,
          declutter: true,
        },
      ]
    },
    { name: 'roads',
      type: 'Group',
      layers: [
        { name: 'roadcl',
          type: 'Vector',
          source: 'roads',
          declutter: true,
          style: (feature, resolution) => {
            let priority = feature.get('p')
            let txt = feature.get('t')
            let color, width
            switch (true) { // resolution
              case (resolution < 3): // ~10k
                width = 5
                break
              case (resolution < 9): // ~30k
                width = 3
                break
              default:
                width = 1
            }
            switch (priority) {
              case 1:
                color = '#dc2500'
                width = width + 3
                break;
              case 2:
                color = '#ffb307'
                width = width + 2
                break;
              case 3:
                color = '#fffa73'
                width = width + 1
                break;
              case 4:
                if (resolution > 75) return
                color = '#fffa73'
                break;
              case 5:
                color = '#eeeeee'
                break;
            }
            let style = [
              rwg.styles.get('roadShadow', {stroke: {width: width + 1}}),
              rwg.styles.get('roadLine', {
                stroke: {width: width, color: color},
              }),
            ]
            if (txt) {
              style.push(
                rwg.styles.get('roadLabel', {
                  text: {text: txt},
                  geom: rwg.clipToExtent(feature, rwg.map),
                })
              )
            }
            return style
          }
        },
        { name: 'railroads',
          type: 'Vector',
          source: 'railroads',
          style: () => [
            rwg.styles.get('rr_tie'),
            rwg.styles.get('rr_line'),
          ],
          zIndex: 5,
        },
        { name: 'shields',
          type: 'Vector',
          source: 'shields',
          declutter: true,
          style: (feature, resolution) => {
            // uses rwg.pointOnLineInView() which requires gwmap.js >= 2024-07-04
            let shields = []
            let xy, xy2, s1, s2
            let num = feature.get('num')
            switch (feature.get('type')) {
              case 'I': // Interstate
                xy =  rwg.pointOnLineInView(feature, 0.25)
                xy2 = rwg.pointOnLineInView(feature, 0.75)
                if (xy) {
                  s1 = rwg.styles.get('shieldInterstate', {xy: xy})
                  s2 = s1.clone()
                  s2.getGeometry().setCoordinates(xy2)
                  shields.push (s1, s2)
                }
                break
              case 'U': // US Hwy
                xy = rwg.pointOnLineInView(feature, 0.5)
                if (xy) {
                  if (num.includes('-')) {
                    shields.push (rwg.styles.get('shieldUS2', {
                      xy: xy,
                      text: {text: num.replace('-','\n')}
                    }))
                  } else {
                    shields.push (rwg.styles.get('shieldUS', {
                      xy: xy,
                      text: {text: num}
                    }))
                  }
                }
                break
              case 'W': // WY Hwy
                xy = rwg.pointOnLineInView(feature, 0.25)  // not at 0.5 because WY Hwys also have names labeled
                if (xy) {
                  shields.push (rwg.styles.get('shieldWY', {
                    xy: xy,
                    text: {text: num}
                  }))
                }
                break
            }
            return shields
          }
        }
      ]
    },
    { name: "lotnum",
      type: 'Vector',
      source: 'lotnumbers',
      style: feature => rwg.styles.get('lotnumbers', {text: {text: feature.get('n')}}),
      minZoom: 15,
      // zIndex: 7,
      declutter: true,
    },
    { name: "stnum",
      type: 'Vector',
      source: 'streetnum',
      style: feature => rwg.styles.get('streetnum', { text: { text: feature.get('n').toString()}}),
      minZoom: 11,
      // zIndex: 7,
      declutter: true,
    },
  ],
  layerOptions: {
    a2025: {
      // imgType: 'jpeg', // using Eagleview WMTS 
      info: () => {}
    },
    // a23: {imgType: 'jpeg', olLyr: "background"},
    a22: {imgType: 'jpeg', olLyr: "background"},
    // a20: {imgType: 'jpeg', olLyr: "background"},
    a19: {imgType: 'jpeg', olLyr: "background"},
    a17: {imgType: 'jpeg', olLyr: "background"},
    a15: {imgType: 'jpeg', olLyr: "background"},
    a12: {imgType: 'jpeg', olLyr: "background"},
    a09: {imgType: 'jpeg', olLyr: "background"},
    a07: {imgType: 'jpeg', olLyr: "background"},
    drg: {imgType: 'jpeg', olLyr: "background"},
    wellheads: {info: records=> rwg.formatInfo(records,[['Well API Number'],['Class'],['Operator'],['Well Name'],['Bottom Hole'],['Elevation GR'],['Elevation KB'],['Total Depth'],['Plug Back'],['Target Formation'],['Coal Bed'],['Status'],['Location']])},
    precincts: { info: records => rwg.formatInfo(records,
      [['District-Precinct'],
      [false, dat => gwmBallotLinks(dat)],  // sample ballots: see GWM-BALLOTS at the top (gwm-ballots)
      ['Polling Place'],['House & Senate'],['School District'],['Fire District']
      ],
      'Voter Precinct')
    },
    ownership: { info: records => {
      let count = rwg.selection.ownership.update(records);
      if (count) {
        rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
        rwg.historyManager.push();
        let s = count > 1 ? 's' : ''
        return rwg.selection.ownership.render( null,
          count + ' Parcel' + s + ' <a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel' + s + '</a>'
        );
      }
    }}
  },
  navbar: {
    jump2s: [
      {'Sheridan County': [-12014817, 5550316, -11805685, 5623696]},
      {'Big Horn': [-11914575, 5568379, -11905016, 5577314]},
      {'City of Sheridan': [-11914073, 5580433, -11901614, 5598396]},
      {'Clearmont': [-11847174, 5557695, -11838823, 5570498]},
      {'Dayton - Ranchester': [-11942182,5600374,-11927621,5608246]},
      {'Story': [-11904700,5552077,-11894795,5559500]}
    ]
  },
  disclaimer: `While we make every effort to produce and publish the most current and accurate information possible,
  Sheridan County makes no warranty of merchantability or fitness of this data for any particular purpose,
  either express or implied. No representation or warranty is made concerning the accuracy, currency,
  completeness or quality of data depicted. Any user of this data assumes all responsibility for use thereof,
  and further agrees to hold Sheridan County and Terra GIS Ltd. harmless from and against any damage, loss,
  or liability arising from any use of this data. While this information is intended to be accurate,
  any manifest errors are unintentional and subject to correction.
  Questions in regards to the parcel map or assessment data should be directed to the Sheridan County Assessor’s office.
  By clicking the button below to launch the map viewer the User accepts these terms of use.`,
  print: {
    disclaimer: "Sheridan County provides this map for illustrative purposes only and assumes no liability for actions taken by users based on information shown.",
    title: "Sheridan County Wyoming MapServer"
  },
  infoLayers: { // below 3 handled by precincts
    fire: ()=>{},
    school: ()=>{},
    senatehouse: ()=>{},
  },
  selectionSets: {
    ownership: [
      ['Parcel'],
      ['Account', dat => '<a href="javascript:rwg.detailTab(\'' +  dat + '\')" class="mapPIDN">Property&nbsp;Detail</a>'],
      ['Tax ID',  dat => '<a href="' + rwgInitParams.propTaxLink + dat + '" target=_blank>Property Taxes</a>'],
      ['Subdiv'],['Lot'],
      ['Name'],['Mail Addr'],['Mail Addr'],['St Addr'],
      ['Deed'],['Reception No'],['Location'],['Type'],['Acres'],
      [false, dat => rwg.mapFeatures(dat)],
      ['LEA'],['Neighborhood'],['Tax District'],['Value Measure'],['Quality'],['Condition'],['Effective Age'],['Field Inspection Date']
    ]
  }
};
