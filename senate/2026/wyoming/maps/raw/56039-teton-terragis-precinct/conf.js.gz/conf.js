document.title='Teton County MapServer';

// GWM-BALLOTS begin: the sample ballot links of the precincts layer. Switch with gwm-ballots (share/gwm_maptools)
// or on the status page (Map Configuration, Ballots), not by hand.
const gwmBallots = {
  "mode": "primary",
  "primary": [
    {
      "base": "https://gwmap.s3.us-west-2.amazonaws.com/tetonwy/ballots/",
      "file": "SAMPLE-DEM-{precinct}.pdf",
      "label": "Democratic Party"
    },
    {
      "base": "https://gwmap.s3.us-west-2.amazonaws.com/tetonwy/ballots/",
      "file": "SAMPLE-REP-{precinct}.pdf",
      "label": "Republican Party"
    },
    {
      "base": "https://gwmap.s3.us-west-2.amazonaws.com/tetonwy/ballots/",
      "file": "SAMPLE-NON-{precinct}.pdf",
      "label": "Non Partisan",
      "only": [
        "01-02",
        "01-04",
        "01-05-01",
        "01-05-02",
        "01-06",
        "01-11"
      ]
    }
  ],
  "precincts": {
    "sql": "select distinct concat(precinct, coalesce('-' || split, '')) from precinct2022"
  }
};
function gwmBallotLinks(dat) {
  // the sample ballot links of one precinct, from gwmBallots (written by gwm-ballots)
  const b = gwmBallots;
  const url = (m) => m.base + m.file.split('{precinct}').join(dat);
  const text = (s) => s.split('{precinct}').join(dat);
  if (b.mode === 'general') {
    return `<a href="${url(b.general)}" target="_blank"><b>${text(b.general.label)}</b></a>`;
  }
  if (b.mode === 'primary') {
    // a link with "only" is shown for those precincts only (Teton's Non Partisan ballot)
    return 'Sample Ballots:<div style="margin-left: 1em;">'
      + b.primary.filter((p) => !p.only || p.only.includes(dat))
        .map((p) => `<a href="${url(p)}" target="_blank">${text(p.label)}</a>`).join('<br>') + '</div>';
  }
  return '';
}
// GWM-BALLOTS end
window.mapParent = function(pidn) {
  var filter = "(pidn in('" + pidn + "'))"; // eslint-disable-line quotes
  rwg.selection.clear();
  rwg.renderInfo(rwg.config.info_url + 'layers=parent&filter=' + filter, true);
};

const rwgInitParams = {
  // mapserv: 'https://gwmap.us/cgi-bin/mapserv76.fcgi',
  mapserv: '/cgi-bin/mapserv76.fcgi',
  defaultImgTyp: 'png8g',
  mapfile: 'MAP22',
  localStoreBase: 'teton',
  defaultBufferDistance: 800,
  featureBufferLayers: [
    { id: 'road_cl', label: 'Roads', table: 'road_cl', schema: 'work', idCol: 'ogc_fid', nameCol: 'label' },
    { id: 'easement', label: 'Easements', table: 'easement', schema: 'work', idCol: 'ogc_fid', nameCol: 'stylecode' },
    { id: 'conservation_easements', label: 'Conservation Easements', table: 'conservation_easements', schema: 'work', idCol: 'pk', nameCol: 'name' },
    { id: 'tcd_swi_lines', label: 'Sewer/Water Lines', table: 'tcd_swi_lines', schema: 'work', idCol: 'objectid', nameCol: 'name' }
  ],
  // search_url:  "./mobile/listJSON.php", // this is only used when 'idnum' is in the query string
  utm_zone: "12",
  statePlane: "EPSG:3739",
  olView: {
    center: [2428680, 1418580],
    extent: [2300000, 1300000, 2700000, 1900000],
    minResolution: 0.2,
    maxResolution: 1000,
    zoom: 4
  },
  olProjection: {code: 'EPSG:3739', units: 'us-ft', extent: [2300000, 1300000, 2700000, 1900000]},
  otherMaps: {
    'Google': { active: true},
    'Bing': { active: true},
    'Google Earth': { active: true},
    'Pictometry Explorer': {active: (location.pathname.indexOf('assessor') > -1)}
  },
  hyphenatePIDN: (n)=> {
    if (n.includes('-')) return n  // it's already hyphenated
    if (isNaN(n.substr(0,2))) return n  // this allows TMP0012345, GRTE, YELLOWSTONE, etc.
    if (n.substr(0,2) != '22') {  // if it doesn't begin with '22' then it's probably a Realware parcelno so prepend '22'
      n = ''.concat('22', n);  // forcing string concatenation not addition
    }
    return n.substr(0,2) + '-' +  // 22
           n.substr(2,2) + '-' +  // 41  twp
           n.substr(4,2) + '-' +  // 17  rng
           n.substr(6,2) + '-' +  // 26  sec
           n.substr(8,1) + '-' +  //  2  qtr
           n.substr(9,2) + '-' +  // 00  blk
           n.substr(11,3);
  },
  viewLayers: "Roads ownership st_num a2022",  // used when map?view=cc and map?view=pd
  fullDrawing: true,
  mapservHilite: true,
  sources: {
    platl: { url: 'json-data/subdiv.topo.json' },
    lot_num: { url: 'json-data/lotno.topo.json' },
    st_num: { url: 'json-data/stnum.topo.json' },
    // road_cl: { url: 'json-data/road_cl.topo.json' },
    road_cl: {  // if OL throws "unimplemented" error  set apache headers content-encoding and content-type
      type: 'MVT',
      url: '/tetonwy/mapserver/mvt/roads/{z}/{x}/{y}.pbf',
      maxZoom: 7,
    },
    // easement: { url: 'json-data/easement.topo.json' },
    easement: {  // if OL throws "unimplemented" error set apache headers content-encoding and content-type
      type: 'MVT',
      url: '/tetonwy/mapserver/mvt/easement/{z}/{x}/{y}.pbf',
      maxZoom: 8,
    },
    placelabels: { url: 'json-data/placelabels.topo.json' },
    state_fed_labels: { url: 'json-data/state_fed_labels.topo.json' },
    precinct:{url: 'json-data/precinct.topo.json'},
    a24: {
      type: 'WMTS',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTTE24-CuWPVxCQfw',
      projection: 'EPSG:3857',
    },
    a22: {
      type: 'WMTS',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTTE22-t9O8X3Pzm9',
      projection: 'EPSG:3857',
    },
    a15: {
      type: 'WMTS',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYTETO15-PHI6ZArtSD',
      projection: 'EPSG:3857',
    },
  },
  styles: {
    placelabels1: {
      text: {
        font: '14pt "Times New Roman", Times, serif',
        fill: {color: '#fff'},
        stroke: {color: '#000', width: 2}, // halo
      },
    },
    placelabels2: {
      text: {
        font: '12pt "Times New Roman", Times, serif',
        fill: {color: '#000'},
        stroke: {color: '#fff', width: 1}, // halo
      },
    },
    platl: {
      stroke: {
        color: '#C5A5E5',
        width: 3, // default = 2
      },
      fill:{color: 'rgba(211,197,225,0.5)'},
    },
    platlLabel: {
      text: {
        font: '8pt Arial, Helvetica, sans-serif',
        stroke: {color: '#7030A0', width: 1}, // halo
      },
    },
    st_num: {
      text: {
        font: '11pt Arial, Helvetica, sans-serif',
        offsetY: 5,
        stroke: {color: 'white', width: 2}, // halo
      },
    },
    lot_num: {
      text: {
        font: '12pt Times New Roman, Times, serif',
        fill: {color: '#000080'},
        offsetY: -5,
        stroke: {color: '#ffffff', width: 2}, // halo
      }
    },
    roadShadow: {
      stroke: {
        color: '#b4b4b4',
        width: 3
      },
      zIndex: 0,
    },
    roadLine: {
      stroke: {
        color: '#dcdcdc',
        width: 2
      },
      zIndex: 1,
    },
    roadLabel: {
      text: {
        placement: 'line',
        maxAngle: Math.PI / 12,
        font: 'bold 14px Arial',
        fill: {color: 'black'},
        stroke: {color: 'white', width: 1},  // do NOT quote the width!
        offsetY: -8,
      },
    },
    easement: {
      stroke: {
        color: '#FD9A04',
        width: 1,
        lineDash: [6,6]
      }
    },
    roofline: {
      stroke: {
        color: '#ff0000',
         width: 1,
         // lineDash: [6,6]
      },
      text: {
        font: 'bold 14px Arial',
        fill: {color: 'black'},
        stroke: {color: 'white', width: 1},  // do NOT quote the width!
        overflow: true,
      },
    },
    prct: {fill: {color:'000'}},
    pollctr:{
      icon: { // https://openlayers.org/en/latest/apidoc/module-ol_style_Icon-Icon.html
        src: '/mapserver/vote32.png',
      },
      text: {
        font: 'bold 14px Arial',
        fill: {color: '#800'},
        stroke: {color: '#fff', width: 1},  // do NOT quote the width!
        offsetX: 50
      },
    },
  },
  olLayers:[
    { name: 'placelabels',
      type: 'Vector',
      source: 'placelabels',
      style: (feature, resolution) => {
        let priority = feature.get('p')
        let txt = feature.get('t')
        txt = txt.replace(/(?![^\n]{1,10}$)([^\n]{1,10})\s/g, '$1\n') //wrap
        if (priority == 1 && resolution > 4) {
          return rwg.styles.get('placelabels1', { text:
            {text: txt}
          })
        } else if (priority == 2 && resolution < 7) {
          return rwg.styles.get('placelabels2', { text:
            {text: txt}
          })
        }
      },
      declutter: true,
    },
    { name: 'state_fed_labels', // state_fed polys are rendered by mapserv
      type: 'Vector',
      source: 'state_fed_labels',
      style: (feature, resolution) => {
        if (!rwg.layers.getLayerByName('state_fed').state) return
        let txt = feature.get('t')
        if (!txt) return
        txt = txt.replace(/(?![^\n]{1,10}$)([^\n]{1,10})\s/g, '$1\n') //wrap
        return rwg.styles.get('placelabels2', { text:
          {text: txt}
        })
      },
      declutter: true,
    },
    { name: 'Roads',
      type: 'Group',
      layers: [
        { source: 'road_cl',
          type: 'VectorTile',
          declutter: true,
          style: (feature, resolution) => {
            let priority = feature.get('p')
            let color = '#eeeeee'
            let width = 2
            let shadowWidth = 3
            let txt = feature.get('t')
            // let shields = []
            let geom
            switch (true) { // resolution
              case (resolution < 8):  // ~10k
                width = 5
                shadowWidth = 7
                break
              case (resolution < 25): // ~30k
                width = 3
                shadowWidth = 5
                break
              default:
                width = 1
                shadowWidth = 3
            }
            switch (priority) {
              case 1: // hwy
                color = '#dc2500'
                width = width + 3
                shadowWidth = shadowWidth + 3
                /*
                if (txt.includes('Hwy') === '') {
                  // let num = 'S Hwy 89'.match(/\d+/g)[0]
                  let g1, g2
                  let s1, s2
                  let geom = feature.getGeometry()
                  if (resolution > 250) {  // one label @ mid point
                    g1 =  geom.getCoordinateAt(0.5)
                  } else {            // two labels spaced equally
                    g1 =  geom.getCoordinateAt(0.33)
                    g2 =  geom.getCoordinateAt(0.67)
                  }
                  if (txt.includes('/')) {
                    txt = txt.replace('/','\n')
                    s1 = rwg.styles.get('shieldUS2', { xy: g1, text: {text: txt.substr(1)} })
                  } else {
                    s1 = rwg.styles.get('shieldUS', { xy: g1, text: {text: txt.substr(1)} })
                  }
                  shields.push (s1)
                  if (g2) {
                    s2 = s1.clone()
                    s2.getGeometry().setCoordinates(g2)
                    shields.push (s2)
                  }
                  txt = ''  // don't label hwys that have shields
                }
                */
                break
              case 2: // county rd
                color = [242, 191, 36]
                width = width + 2
                shadowWidth = shadowWidth + 2
                break
              case 3: // ToJ
                if (resolution > 87) return
                break
              case 4:
                if (resolution > 60) return
                break
              case 5:
                width = width + 2
                shadowWidth = shadowWidth + 2
                break
              case 9: // pathways
                if (resolution > 25) return
                color = [50, 133, 27]
                width = width - 2
                shadowWidth = shadowWidth - 2
                break
            }
            // if (txt) { geom = rwg.clipToExtent(feature, rwg.map) }
            let style = [
              rwg.styles.get('roadShadow', {
                stroke: {width: shadowWidth}
              }),
              rwg.styles.get('roadLine', {
                stroke: {width: width, color: color},
              }),
              rwg.styles.get('roadLabel', {
                text: {text: txt},
                geom: geom,
              }),
              // ...shields
            ];
            return style
          }
        },
        { source: 'easement',
          type: 'VectorTile',
          style: (feature) => {
            let color
            switch (feature.get('t')) {
              case 'R': // road
                color = [253, 154, 4]
                break
              case 'P': // pathway
                color = [168, 80, 255]
                break
              case 'L': // levee
                color = [102, 255, 255]
                break
            }
            return rwg.styles.get('easement', {stroke: {color: color}})
          },
          maxResolution: 7,
        },
      ]
    },
    { name: 'platl',  // subdivisions
      type: 'Vector',
      source: 'platl',
      style: (feature, resolution) => {
        let txt = feature.get('name')
        if (txt) txt = txt.replace(/(?![^\n]{1,10}$)([^\n]{1,10})\s/g, '$1\n') //wrap
        let style = [rwg.styles.get('platl')]
        let geom = rwg.clipToExtent(feature, rwg.map)
        if (geom) {
          style.push(rwg.styles.get('platlLabel', {
            text: {text: txt},
            geom: geom
          }))
        }
        return style
      },
      declutter: true,
    },
    { name: 'precinct2022',
      type: 'Group',
      layers: [
        { source: 'precinct',
          type: 'Vector',
          opacity: 0.7,
          zIndex: 5,
          style: (feature) => {
            let prct = feature.get('precinct')
            let c
            if (prct) {
              switch (prct) {
                case "01-01": c="#a0ffa0"; break
                case "01-02": c="#9dbed4"; break
                case "01-03": c="#d3eceb"; break
                case "01-04": c="#c800c8"; break
                case "01-05": c="#ffd0a0"; break
                case "01-06": c="#ffd0ff"; break
                case "01-07": c="#7490c3"; break
                case "01-10": c="#8ab5a9"; break
                case "01-11": c="#fcf9a5"; break
                case "01-12": c="#8DDFF9"; break
                case "02-01": c="#F9F98D"; break
                case "03-01": c="#ff90c8"; break
                case "04-01": c="#bf84ca"; break
                case "04-02": c="#f59f43"; break
                case "04-03": c="#7490c3"; break
                case "04-04": c="#b2feca"; break
                case "05-01": c="#8ca958"; break
              }
              return rwg.styles.get('prct', {fill: {color: c}})
            }
          }
        },
        { source: 'precinct',
          type: 'Vector',
          // declutter: true,
          zIndex: 10,
          style: (feature, resolution) => {
            let prct = feature.get('precinct')
            if (prct) {
              return rwg.styles.get('placelabels1', {
                text: {text: prct},
                geom: rwg.clipToExtent(feature, rwg.map),
              })
            } else { // pollctr
              let txt = feature.get('label2')
              txt = txt.replace(/(?![^\n]{1,10}$)([^\n]{1,10})\s/g, '$1\n') //wrap
              return rwg.styles.get('pollctr', { text: {text: txt}})
            }
          }
        }
      ]
    },
    { name: 'lot_num',
      type: 'Vector',
      source: 'lot_num',
      style: (f, r) => {
        if (r > 100) return  // ~1:115k
        let style = rwg.styles.get('lot_num')
        style.getText().setText(f.get('id'))
        return style
      },
      declutter: true,
    },
    { name: 'st_num',
      type: 'Vector',
      source: 'st_num',
      style: (f, r) => {
        if (r > 100) return  // ~1:115k
        let a = f.get('a').replace('#', '\n#');  // a = concat(st_num, st_unit) so wrap on #
        if (a) {
          let style = rwg.styles.get('st_num')
          style.getText().setText(a)
          return style
        }
      },
      declutter: true,
    },
    { name: 'a2024',
      source: 'a24',
      // extent: [], // extent should be epsg:3739 despite the source being epsg:3857
    },
    { name: 'a2022',
      source: 'a22',
      // extent: [], // extent should be epsg:3739 despite the source being epsg:3857
    },
    { name: 'a2015',
      source: 'a15',
      // extent: [], // extent should be epsg:3739 despite the source being epsg:3857
    },
  ],
  layerOptions: {
    a2024: {
        // imgType: 'jpeg', // using Eagleview WMTS 2025-03-12
        info: () => {}
    },
    a2022: {
      // imgType: 'jpeg', // using Eagleview WMTS 2024-04-08
      info: () => {}
    },
    a2020: {imgType: 'jpeg'},
    a2019: {imgType: 'jpeg', info: () => {} },  // handled by infoLayers.photodate()
    a2017: {imgType: 'jpeg', info: () => {} },
    a2017ir: {imgType: 'jpeg', info: () => {} },
    // a2015: {imgType: 'jpeg', info: () => {} }, // using Eagleview WMTS 2024-04-08
    a2015ir: {imgType: 'jpeg', info: () => {} },
    a2013: {imgType: 'jpeg', info: () => {} },
    a2013ir: {imgType: 'jpeg', info: () => {} },
    a2012: {imgType: 'jpeg'},
    a2011: {imgType: 'jpeg', info: () => {} },
    a2011ir: {imgType: 'jpeg', info: () => {} },
    a2009: {imgType: 'jpeg'},
    a2008: {imgType: 'jpeg'},
    a2008ir: {imgType: 'jpeg'},
    a2007: {imgType: 'jpeg'},
    a2005: {imgType: 'jpeg'},
    a2003: {imgType: 'jpeg'},
    a2002: {imgType: 'jpeg'},
    a2001: {imgType: 'jpeg'},
    a1999: {imgType: 'jpeg'},
    a1994: {imgType: 'jpeg'},
    a1983: {imgType: 'jpeg'},
    a1989: {imgType: 'jpeg'},
    a1978: {imgType: 'jpeg'},
    a1977: {imgType: 'jpeg'},
    a1967: {imgType: 'jpeg'},
    a1955: {imgType: 'jpeg'},
    a1945: {imgType: 'jpeg'},
    DRG: {imgType: 'jpeg'},
    lodgingov: { info: records => rwg.formatInfo(records,[['Lodging Overlay - LDR Section']])},
    veg: {info: records => rwg.formatInfo(records,
      [['Cover Type'],['Species'],['Area'],['Min Height (ft)'],['Max Height (ft)'],['Median Height (ft)'],['Average Height (ft)'],['Min Slope (%)'],['Max Slope (%)'],['Average Slope (%)']],
      'Vegetation and Land Cover (2024)'
    )}, // veg_cname, acres || ' acres (' || hectares || ' ha)', dom_mod, hgt_min, hgt_max, hgt_med, hgt_avg, slp_min, slp_max, slp_avg
    cornerrec: { info: records => rwg.formatInfo(records, [['Corner Record', dat => `<a href="/tetonwy/landrec/query/signeddoc.php?doc=${dat}" target="_blank">View</a>`]]) },
    tcdswi: { info: records =>  rwg.formatInfo(records, [
        ['Name'],
        ['Permit'],
        ['Alias'],
        ['Alternate Permit'],
        ['Priority Year'],
        ['Type'],
        ['Shape Source'],
        ['Name Source'],
        ['Stream Source'],
        ['Length Mi.'],
        ['Res. Size (Acre Feet)'],
        ['Acres'],
        ['Watershed'],
        ['Sub Watershed'],
      ],
      'TCD Surface Water Inventory'
    )},
    // Keep landslides because they are in the staff mapserv
    landslides: { info: records => rwg.formatInfo(records,
        [['Landslide of type(s)']],
        'All land slides should be considered a potential hazard. Have the site inspected by a registered  professional geologist or professional engineer, and/or Contact the <a href="http://www.wsgs.uwyo.edu/" target="_blank">Wyoming State Geologic Survey</a> for more information at: (307) 766-2286<br><a href="http://www.wrds.uwyo.edu/wrds/wsgs/hazards/landslides/mapabbrev.html" target="_blank"> List of Landslide Type Abbreviations</a>'
    )},
    zoning: { info: records => rwg.formatInfo(records,[['Zoning'],['LDR Section']])},
    oldZoning: { info: records => rwg.formatInfo(records, [['Zoning prior to 4/1/16']])},
    ToJ_Zoning: { info: records => rwg.formatInfo(records, [['Zoning'],['LDR Section']], 'Town of Jackson Zoning')},
    contour: { info: records => rwg.formatInfo(records,[['Lidar Acquisition Date']]) },
    chardist: { info: records => rwg.formatInfo(records,[[''],['Sub Area']], 'Comprehensive Plan Character District')},
    precinct2012: { info: () => {}},
    precinct2022: { info: () => {}},
    firm: { info: records =>  rwg.formatInfo(records, [['FEMA Flood Hazard Zone'],['Effective Date'],['FIRM Panel']]) },
    conserv_esmnt: { info: records => rwg.formatInfo( records, [
        ['Held By'],
        ['Recording'],
        ['Document'],
        ['Amendment'],
        ['Amendment'],
        ['Location'],
        ['Density Bonus'],
        ['Reserved Homesites'],
        ['Building Envelope'],
        ['Baseline'],
        ['Grantor'],
        ['Notes'],
        ['Year Protected'],
        ['Fee Simple or Easement']],
      '<b>Conservation Easement</b>'
    )},
    Roads:{info:()=>{}}, // handled by infoLayers.levee() & infoLayers.road_cl(),
    sd_alta:{info:()=>{}}, // handled by infoLayers.special_districts(),
    sd_aspenswatersewer:{info:()=>{}},
    sd_aspensisd:{info:()=>{}},
    sd_buffalo:{info:()=>{}},
    sd_campcreek:{info:()=>{}},
    sd_fishcreek:{info:()=>{}},
    sd_flatcreek:{info:()=>{}},
    sd_grandtarghee:{info:()=>{}},
    sd_grosventre:{info:()=>{}},
    sd_hicountry:{info:()=>{}},
    sd_hoback:{info:()=>{}},
    sd_indian:{info:()=>{}},
    sd_melody:{info:()=>{}},
    sd_obar:{info:()=>{}},
    sd_polo:{info:()=>{}},
    sd_porcupine:{info:()=>{}},
    sd_rafterj:{info:()=>{}},
    sd_rivermeadow:{info:()=>{}},
    sd_ridgeline:{info:()=>{}},
    sd_skyline:{info:()=>{}},
    sd_springcreek:{info:()=>{}},
    sd_spsc:{info:()=>{}},
    sd_squawcreek:{info:()=>{}},
    sd_srsc:{info:()=>{}},
    sd_southsquawcreek:{info:()=>{}},
    sd_targheetowne:{info:()=>{}},
    sd_villageassocisd:{info:()=>{}},
    sd_villagefire:{info:()=>{}},
    sd_villageisd:{info:()=>{}},
    sd_villageresort:{info:()=>{}},
    sd_villagewatersewer:{info:()=>{}},
    sd_villageroad:{info:()=>{}},
    sd_westgrosventrewater:{info:()=>{}},
    sd_willowbrook:{info:()=>{}},
    sd_wilson:{info:()=>{}},
    slopesA:{info:()=>{}}, // handled by infoLayers.slopes()
    slopesZ:{info:()=>{}},
    pls: { info: records => rwg.formatInfo(records, [['']]) },
    state_fed: {
      info: records => rwg.formatInfo(records,[['']]),
      olLyr2: 'state_fed_labels' // polys rendered by mapserv, labels rendered by ol
    },
    ownership: { info: (records) => {
      let count = rwg.selection.ownership.update(records);
      if (count) {
        rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
        rwg.historyManager.push('info');
        return rwg.selection.ownership.render(null, `<div class = "align-left-right"><div>${count} Parcel(s)</div><a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel(s)</a>`);
      }
    }},
    rooflines: {info: records => rwg.formatInfo(records,
      [['Status'], ['area'], ['previous area'], ['percent change']],
      'Change Finder'
    )},
  }, // layerOptions
  selectionSets: {
    ownership: [
      ['Parcel'],
      [''],[''],[''], // [''], // clerk, parentParcel, smartGov, cityView
      ['Account', dat => `<a href="javascript:rwg.detailTab('${dat}')" class="mapPIDN">Property Detail</a>`],
      [''],['Map Number'],
      ['Lot'],['Owner'],['MailAddr'],['MailAddr'],
      ['StAddr'],['Deed'],['Location'],['TaxClass'],['Acreage'],
      [false, dat => rwg.mapFeatures(dat)],
      [false, dat => rwg.mapFeatures(dat)],
      ['LEA'],['Neighborhood'],['Tax District'],['Value Measure'],['Quality'],['Condition'],['Effective Age'],['Retired Date'],['Retired By']
    ]
  },
  navbar: {
    jump2s: [
      {'Initial View': [2403500, 1399500, 2452820, 1441200]},
      {'Town of Jackson':[2427000, 1403000, 2454000, 1422000]},
      {'Alta':[2369000, 1514000, 2384670, 1524400]},
      {'Aspens / Teton Pines':[2417850, 1425540, 2433500, 1436000]},
      {'Buffalo Valley': [2515850, 1537950, 2547200, 1558800]},
      {'Hoback Junction': [2424400, 1343530, 2487090, 1385230]},
      {'Kelly': [2475128, 1460985, 2486717, 1469660]},
      {'Teton Village': [2411270, 1443314, 2442675, 1464234]},
      {'Wilson': [2412234, 1418160, 2420916, 1424670]}
    ]
  },
  initCode: {
    misc: () => rwg.tax_exempt = ["NONTAX","000000","ADDRES"], // tax_id that indicates exempt status
    /* disclaim: () => {
      if (!rwg.config.showDisclaimer === false) {
        let response = prompt(`Terra GIS Ltd. is not currently under contract with Teton County to provide this web service. Terra GIS is temporaily providing this as a public service. You must agree to hold Terra GIS Ltd. harmless from and against any and all liability which may arise as a result of the use of the maps and data provided on this web site by typing "agree" below.`)
        if (!response || response.toLowerCase().trim() !== 'agree' ) {
          window.location.replace("https://www.tetoncountywy.gov");
        }
      }
    }, */
  },
  /*
    infoLayers provides info handlers for layers that aren't in the legend.
    infoLayers can provide additional handlers for grouped layers
      e.g. conserv_esmnt is a single layer in the legend but has multiple info layers in postgres
    and infoLayers can provide a single info handler for multiple layers in the legend
      e.g. photodate() for all the aerial photography layers
   */
  infoLayers: { //these are layerOptions that share a function or are layers that are grouped in the mapfile/dlegend or are not in the mapfile/dlegend (parent info)
    parent: records => { // This is for parent parcel and is the same as ownership except don't push history, needs to be here because it is not in mapfile/dlegend
      let count = rwg.selection.ownership.update(records);
      if (count) {
        rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
        return rwg.selection.ownership.render(null, `<div class = "align-left-right"><div>${count} Parcel(s)</div><a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel(s)</a>`);
      }
    },
    photodate: records => rwg.formatInfo(records, [['Aerial Photography Date']]), // used by imagery layers
    special_districts: records =>  // used by all special_districts
      rwg.formatInfo(records,
        [['', dat => `<a href="download/special_district_parcels.php/?dist=${dat}" target="_blank">List of parcels</a>`]]
      ),
    slopes: records => rwg.formatInfo( records, [  // used by slopesA and slopesZ
      [false, dat => `Slope: ${Math.round(dat)}°` + (dat < 45 ? `, ${Math.round(Math.tan(dat * 0.0174532925199) * 100)}%` : '')] // D2R
    ]),
    levee: records => rwg.formatInfo(  //Roads dlegend group
      records,
      [ [''],
        ['Grantor'],
        [''],
        ['Secondary Document'],
        ['Secondary Document'],
        ['Unrecorded Document'],
        ['Unrecorded Document'],
        ['Spatial Source'],
        ['Notes'] ],
      '<b>Levee</b>'
    ),
    road_cl: function(records) {  //Roads dlegend group, query only returns county roads
      return rwg.formatInfo( records, [
        [''],
        [false],
        ['Number', function(dat) {
          let html = ''
          if (dat.substr(0, 5) !== '22-CM') {
            html += '<a href="https://maps.terragis.net/tetonwy/landrec/scannedMaps/scanned_map.php?number=' + dat + '" target="_blank">Scanned Map</a>'
          }
          if (document.getElementById('roads')) {
            html += '<br>Road Department data for <a href="javascript:roadTab(\'' + dat + '\', \'road\')">' + dat + '</a>';
          }
          return html;
        }]
        ],
        '<b>County Road</b>');
    },
    precinct: records => rwg.formatInfo(records, [
      ['Precinct'],['State House District'],['State Senate District'],
      [false, dat => gwmBallotLinks(dat)],  // sample ballots: see GWM-BALLOTS at the top (gwm-ballots)
      ],
      '&nbsp;Voter Precincts'),
  }, // infoLayers
  disclaimer: `Teton County makes no claims as to the absolute validity or reliability of the maps and data on this site or their fitness for any particular use. All maps and data contained herein are provided "as is". All implied warranties, including but not limited to the implied warranties of merchantability and fitness for a particular purpose, are expressly disclaimed. The user agrees to hold harmless Teton County and Terra GIS Ltd. from and against any and all liability which may arise as a result of the use of the maps and data provided to the user on this web site.`,
  print: {
    "title": "Teton County Wyoming MapServer",
    "disclaimer": "Teton County provides this map for illustrative purposes only and assumes no liability for actions taken by users based on information shown."
  },
} // rwgInitParams

// TCHP (historic preservation) info handlers, own file kept out of the gwm-wip hold; written here
// because the public map (include/gwmap.html) loads only legend.js and conf.js from etc/
// document.write('<script src="etc/conf-tchp.js?v=20261003e"></script>');
