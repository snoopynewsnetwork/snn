document.title = 'Sweetwater County, Wyoming, MapServer';
const baseURL = 'https://sweetwater.s3.us-west-002.backblazeb2.com/';
const rwgInitParams = {
  demimalMinutes: true, // an option for Sweetwater County to display info click in degrees, decimal minutes
  utm_zone: '12',
  statePlane: 'EPSG:3738',
  olProjection: { code: 'EPSG:3738', units: 'us-ft', extent: [1606000, 175000, 2313000, 648000] },
  olView: {
    extent: [1606000, 175000, 2313000, 648000],
    minResolution: 0.2,
    maxResolution: 1000,
  },
  mapfile: 'MAP04',
  mapserv: '/w5/cgi-bin/mapserv76.fcgi', // 'https://w5.gwmap.us/cgi-bin/mapserv76.fcgi',
  defaultImgTyp: 'png8g',
  otherMaps: { 'Google': {active: true}, 'Bing': {active: true}, 'Google Earth': {active: true} },
  hyphenatePIDN: (n) => { // called in history.js
    if (n.indexOf('-') !== -1) {  // already hyphenated
      return n;
    } else {
      return n.substr(0,4) + '-' + // 1905 twp+rng
             n.substr(4,2) + '-' + //   34 sec
             n.substr(6,1) + '-' + //    3 qtr
             n.substr(7,2) + '-' + //   00 blk
             n.substr(9,3) + '-' + //  005 lot
             n.substr(12,2);       //   00 suffix
    }
  },
  mapservHilite: true,  // req'd for road list
  fullDrawing: true,
  layerChangeCallback: (name, state) => { // for irrigated & planning notes
    if (name === rwg.config.editable) rwg.config.saveFeatures = state
  },
  sources:{
    a25: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTSW25-G0gkvF1AON',
    },
	precincts: { url: 'json-data/precincts.topo.json' },
    railroads: { url: 'json-data/railroads.topo.json' },
    cities: { url: 'json-data/cities.topo.json' },
    roads: { type: 'MVT', url: 'mvt/roads/{z}/{x}/{y}.pbf', maxZoom: 7 },
    biketrails: {  // not currently in use
      url: 'json-data/biketrails.topo.json',
      extent: [1778100,358168,1795650,367478],
    },
    irrigated: {
      url: './crud.php',
      data: {
        action: 'get',
        table: 'irrigated',
      },
      properties: {
        attributes: ['label', 'notes'],
      },
      // loaded: function(returned) {console.log(returned);},
    },
    notes: {
      url: './crud.php',
      data: {
        action: 'get',
        table: 'notes',
      },
      properties: { attributes: ['label', 'notes']},
      // loaded: function(returned) {console.log(returned)},
    },
  },
  // get the road names for the pick list
  // rwg.sources.list.roads.getFeatures().forEach(f => console.log(f.get('txt')))
  /* lyrDrawStyles: {
    strokeRGB: '255, 165, 0',
    outlineRGB: '255, 165, 0',
    fillRGB: '255, 255, 0',
    fontOutlineWidth: '2',
    labelMaxRes: 9999999,
    overflow: true
  }, */
  styles: {
    roadShadow: {
      stroke: { color: "#8c8c8c", width: 3 },
      zIndex: 0,
    },
    roadLine: {
      stroke: {},
      zIndex: 1,
    },
    roadLabel: {
      text: {
        placement: 'line',
        // maxAngle: Math.PI / 12,
        font: 'bold 14px Arial, Helvetica, sans-serif',
        fill: {color: 'black'},
        stroke: {color: 'white', width: 1},  // do NOT quote the width!
      },
    },
    roadLabelReversed: {
      text: {
        placement: 'line',
        maxAngle: Math.PI / 12,
        font: 'bold 14px Arial, Helvetica, sans-serif',
        fill: {color: 'white'},
        stroke: {color: '#666', width: 2},  // do NOT quote the width!
      },
    },
    shieldInterstate: {
      xy: [],
      icon: {
        src: '/mapserver/interstate.png',
      },
      text: {
        placement: 'point',
        font: 'bold 14px Arial, Helvetica, sans-serif',
        fill: {color: '#ffffff'},
        text: '80'
      },
      zIndex: 1,
    },
    shieldUS: {
      xy: [],
      icon: {
        src: '/mapserver/ushwy.png',
        scale: 0.7
      },
      text: {
        font: 'bold 10px Arial, Helvetica, sans-serif',
        offsetY: 1,
      },
      zIndex: 1,
    },
    shieldWY: {
      xy: [],
      icon: {
        src: '/mapserver/wyhwy.png',
        scale: 0.7,
      },
      text: {
        placement: 'point',
        offsetY: 2,
        font: 'bold 10px Arial, Helvetica, sans-serif',
      },
      zIndex: 1,
    },
    rr_tie: {
      stroke: {
        color: '#888',
        width: 8,
        lineDash: [1,20],
        lineCap: 'butt',  // butt, round, square (defaults to 'round')
        // lineJoin: 'miter', // bevel, round, miter (defaults to 'round')
        // lineDashOffset: 0,  // default 0
        // miterLimit: 10,  // limit on the ratio of the miter length to the stroke-width used to draw a miter join. When limit is exceeded, the join is converted to a bevel, default: 10
      },
      zIndex: 1,
    },
    rr_line: {
      stroke: { color: '#888', width: 1 },
      zIndex: 2,
    },
    biketrails: {
      stroke: { width: 1 },
      text: {
        placement: 'line', // 'point' (default)
        maxAngle: Math.PI / 12,
        font: 'bold 14px Arial, Helvetica, sans-serif',
        stroke: {width: 1},  // do NOT quote the width!
        offsetY: -6,
      },
    },
    irrigated: {
      stroke: {color: 'rgba(255, 165, 0, 0.5)', width: 2},
      fill: {color: 'rgba(245, 255, 138, 0.5)'},
      text: {
        font: 'bold 14px Arial, Helvetica, sans-serif',
        fill: {color: '#000000'},
        stroke: {color: '#ffffff', width: 1},  // do NOT quote the width!
      },
    },
    notes: { // planning office
      stroke: {color: 'rgba(0, 0, 0, 0.5)', width: 2},
      fill: {color: 'rgba(255, 255, 255, 0.2)'},
      text: {
        font: 'bold 14px Arial, Helvetica, sans-serif',
        fill: {color: '#000000'},
        stroke: {color: '#ffffff', width: 1},  // do NOT quote the width!
      },
    },
    cities: {
      stroke: {
        color: '#f80',
        width: 6,
        lineDash: [4, 8],
        // lineDashOffset: 6
      }
    },
    citiesLabels: {
      text: {
        font: '16px Arial, Helvetica, sans-serif',
        // fill: {color: '#666'},
        stroke: {color: '#f80', width: 2},
        overflow: true,
      }
    },
    poly: {fill: {color: '#000'}},
    precinctsLabel: {
      text: {
        font: 'bold 12pt Arial, Helvetica, sans-serif',
        stroke: {color: '#fff', width: 2},
      }
    },
  },
  olLayers: [
    { name: 'a2025',
      source: 'a25',
      // extent: [], // extent should be epsg:3739 despite the source being epsg:3857
    },    
    { name: 'precinct22',
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'precincts',
          opacity: 0.5,
          style: feature => {
            let colors = {'01-2':[24,93,38],'03-4':[31,2,3],'03-6':[97,136,146],'03-7':[154,155,43],'04-1':[170,115,90],'04-4':[15,155,200],'04-5':"#3FD409",'04-6':[224,186,244],'04-7':[237,138,37],'05-10':[118,61,220],'05-6':[54,199,216],'05-7':[255,255,156],'05-8':[255,156,156],'05-9':[101,68,76],'06-1':[215,7,96],'06-3':[24,173,15],'06-5':[3,235,71],'06-6':[70,150,177],'07-3':[214,186,124],'07-4':[53,190,120],'09-3':[117,243,190],'10-10':[28,153,99],'10-11':[188,156,146],'10-12':[93,39,58],'10-13':[109,205,132],'10-8':[253,192,89],'10-9':"#BFBFBF",'12-2':[17,179,129],'13-2':[43,253,114],'19-1':[38,243,37],'20-2':[231,177,78],'21-1':[109,18,247],'23-2':[175,40,224],'24-1':[210,149,49],'25-2':[46,209,122]}
            let c = colors[feature.get('p')]
            return rwg.styles.get('poly', {fill: {color: c}})
          }
        },
        { type: 'Vector',
          source: 'precincts',
          zIndex: 7,
          declutter: true,
          style: feature => rwg.styles.get('precinctsLabel', {
            text: {text: feature.get('p')},
            geom: rwg.pointInPolyInView(feature)
          })
        }
      ]
    },
    { name: 'irrigated',
      type: "Vector",
      source: 'irrigated',
      visible: false, // so that the source isn't loaded when not needed
      style: (feature) => rwg.styles.get('irrigated', { text: {text: feature.get('label')} })
    },
    { name: 'notes',
      type: 'Vector',
      source: 'notes',
      visible: false, // so that the source isn't loaded when not needed
      style: (feature) => rwg.styles.get('notes', { text: {text: feature.get('label')} })
    },
    { name: 'cities',
      type: 'Group',
      layers: [
        { type: 'Vector',
          source: 'cities',
          style: () => rwg.styles.get('cities')
        },
        { type: 'Vector',
          source: 'cities',
          zIndex: 7,
          declutter: true,
          style: feature => rwg.styles.get('citiesLabels', {text: {text: feature.get('Munic').replace(' ', '\n')}})
        },
      ]
    },
    { name: 'roads',
      type: 'Group',
      layers: [
        { name: 'roadcl',
          type: 'VectorTile',
          source: 'roads',
          declutter: true,
          style: (feature, r) => {
            let priority = feature.get('pr')
            let txt = feature.get('txt')
            let labelStyle = 'roadLabel'
            let shields = []
            let color, width
            switch (true) {   // resolution
              case (r < 8): // ~10k
                width = 5
                break
              case (r < 25): // ~30k
                width = 3
                break
              case (r < 62): // ~70k
                width = 1
                break
              case (r < 125): // ~140k
                width = 0
                break
              default:
                width = -1
            }
            switch (priority) {
              case 51:  // I-80e
                shields.push (rwg.styles.get('shieldInterstate', { xy: feature.getGeometry().getFlatMidpoint() }))
                // shields.push (rwg.styles.get('shieldInterstate', { xy: rwg.pointOnLineInView(feature, 0.5)}))
                // fall thru
              case 50:  // I-80 west
                color = [220, 37, 0]
                width = width + 4
                break;
              case 45: // I-80 business
                if (r > 10) width = 3
                else if (r > 4) width = 4
                else if (r > 1) width = 8
                else width = 12
                color = [220, 37, 0]
                break;
              case 40: // US Hwy
                color = "#3939DE"
                width = width + 4
                shields.push (rwg.styles.get('shieldUS', {
                  xy: feature.getGeometry().getFlatMidpoint(),
                  text: {text: txt.replace(/[A-Z]/g, '').trim()}
                }))
                txt = ''
                break;
              case 30:  // Wyo Hwy
                color = "#FFB307"
                width = width + 3
                shields.push (rwg.styles.get('shieldWY', {
                  xy: feature.getGeometry().getFlatMidpoint(),
                  text: {text: txt.replace(/[A-Z]/g, '').trim()}
                }))
                txt = ''
                break;
              case 20:  // County Rd
                if (r > 10) width = 2
                else if (r > 4) width = 4
                else if (r > 1) width = 8
                else width = 12
                color = "#970404"
                labelStyle = 'roadLabelReversed'
                break;
              case 8:  // BLM
                color = [255, 250, 115]
                width = 1
                break;
              case 6:  // USFS
                color = "#00ff00"
                width = 1
                break;
              case 4:  // misc, city streets
                if (r > 10) width = 1
                else if (r > 4) width = 4
                else if (r > 1) width = 8
                else width = 12
                color = "#ffffff"
                break;
              case 2: // I-80 ramps
                if (r > 100) return
                if (r > 10) width = 2
                else if (r > 4) width = 4
                else if (r > 1) width = 8
                else width = 12
                color = [220, 37, 0]
                break;
              // default:
            }
            let style = [
              rwg.styles.get('roadShadow', {stroke: {width: width + 1}}),
              rwg.styles.get('roadLine', {
                stroke: {width: width, color: color},
              }),
            ]
            if (txt) {
              style.push( rwg.styles.get(labelStyle, { text: {text: txt} })  )
            }
            style.push( ...shields)
            return style
          }
        },
        { source: 'railroads',
          type: 'Vector',
          style: () => [
            rwg.styles.get('rr_tie'),
            rwg.styles.get('rr_line'),
          ],
          zIndex: 5,
        },

        /* { name: 'biketrails',
          type: 'Vector',
          source: 'biketrails',
          extent: [1778100, 358168, 1795650, 367478],
          maxResolution: 100,
          style: feature => {
            let colors = ['green', 'blue', 'black']
            let color = colors[feature.get('class')]
            return rwg.styles.get('biketrails', {
              stroke: {color: color},
              geom: rwg.clipToExtent(feature, rwg.map),
              text: {text: feature.get('t').replace('_', '\n')},
              // placement: 'point', // doesn't get propagated
            })
          },
          zIndex: 5,
        }, */
      ]
    },

  ],
  layerOptions: {
    a2025: {
      // imgType: 'jpeg', // using Eagleview WMTS 
      info: () => {}
    },	  
    a23: {imgType: 'jpeg'},
    a22: {imgType: 'jpeg'},
    a20: {imgType: 'jpeg'},
    a19: {imgType: 'jpeg'},
    a19ir: {imgType: 'jpeg'},
    a17: {imgType: 'jpeg'},
    a15rs: {imgType: 'jpeg'},
    a15: {imgType: 'jpeg'},
    a12: {imgType: 'jpeg'},
    a09: {imgType: 'jpeg'},
    a06: {imgType: 'jpeg'},
    aerialGR: {imgType: 'jpeg'},
    aerialRS: {imgType: 'jpeg'},
    drg: {imgType: 'jpeg'},
    // wfs: { attributes: ['label'], olLyr: 'lyrDraw' },
    /*
    range_owner: { info: function(records) { return rwg.formatInfo(
      records, [['Abstract Code'],['LRA'],['Soils Class'],['Acres'],['Account']],'Rangeland');
    }},
    irr_owner: { info: function(records) { return rwg.formatInfo(
      records, [['Abstract Code'],['LRA'],['Soils Class'],['Acres'],['Account']],'Irrigated land');
    }},
    */
    aglayer: {info: records => {
      if (records.length) {
        let accountno = records[0][0]
        return rwg.formatInfo(records, [
          [false],
          ['' ],
        ], accountno + ' Ag Land acreage by abstract code')
      }
    }},
    mckinnonirr: { info: records => rwg.formatInfo(records,[['']]) },
    ownership: { info: records => {
      let count = rwg.selection.ownership.update(records);
      if (count) {
        rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
        rwg.historyManager.push();
        let s = count > 1 ? 's' : ''
        return rwg.selection.ownership.render( null,
          count + ' Parcel' + s + ' <a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel' + s + '</a>'
        );
      } else {
        rwg.filter = '';
        rwg.historyManager.push();
      }
    }},
    precinct22: { info: records => rwg.formatInfo(records,[
        ['Precinct'],['Polling Place'],['House District'],['Senate District'], ['Ward']
      ])
    },
    farmunits: { info: records => rwg.formatInfo(records,[['Farm Unit']]) },
    zoning: { info: function(records) {return rwg.formatInfo(records, [['Current Zoning'],['Overlay']]);}},
    hydrantsCO: { info: records => rwg.formatInfo(records, [['Number'],['Location'],['District'],['Lat Long'],['Type']], 'Fire Hydrant(s)' )},
    cornerrec: { info: records => rwg.formatInfo(records,[
        [false, dat => `<a href="${baseURL}corners/${dat}" target="_blank">Corner Record</a>` ]
    ])},
    wellheads: {info: function(records) {
      var count = rwg.selection.wellheads.update(records);
      if (count) {
        return rwg.selection.wellheads.render(null, count + ' Wellhead(s)');
      }
    }},
  },  // layerOptions
  navbar: {
    jump2s: [
      {'Sweetwater County': [1606000, 175000, 2313000, 648000]},
      {'Bairoil': [2283000, 630000, 2301000, 645000]},
      {'Farson / Eden': [1750000, 579000, 1823000, 627000]},
      {'Granger': [1626000, 388000, 1655000, 414000]},
      {'Green River': [1752000, 348000, 1791000, 384000]},
      {'McKinnon': [1633000, 193000, 1648000, 205000]},
      {'Point of Rocks': [1948000, 422000, 1974000, 436000]},
      {'Rock Springs': [1814000, 382000, 1895000, 422000]},
      {'Superior': [1902000, 453000, 1916000, 465000]},
      {'Wamsutter': [2170000, 418000, 2189000, 435000]}
    ],
    tools: ['infobox', 'geoloc', 'measline', 'measarea', 'pointText', 'select', 'zoom2ll', 'buffer', 'clear']
  },
  selectionSets: {
    ownership: [
      ['Parcel'],
      ['Account#', dat => '<a href="javascript:rwg.detailTab(\'' +  dat + '\')" >Property Detail</a>'],
      ['Property Taxes', dat => '<a href="https://itax.sweetwatercountywy.gov/detail.aspx?taxid=' + parseInt(dat.substr(1,10), 10) + '" target=_blank>Treasurer</a>'], // strip the leading 'R' and '0' for SWCO
      // Map numbers > 1000 are trailer parks that do not have scanned maps
      ['Map Number', num => parseInt(num) < 1000 ? `<a href="${baseURL}plats/${num}.pdf" target="_blank"> Scanned Map</a>` : ''],
      ['Lot'],
      ['Owner'],['Mail Addr'],['Mail Addr'],
      ['St Addr'],
      ['Deed'],['Location'],
      ['Tax Classification'],['Tax Roll Acreage'],
      [false, dat => rwg.mapFeatures(dat)],
      [false, dat => rwg.mapFeatures(dat)],
      ['LEA'],['Neighborhood'],['Neighborhood Extension'],['Value Measure'],['Quality'],['Condition'],['Detailed Review Date']
    ],
    wellheads: [['Well API Number'],['Class'],['Operator'],['Well Name'],['Bottom Hole'],['Elevation GR'],['Elevation KB'],['Total Depth'],['Plug Back'],['Target Formation'],['Coal Bed'],['Status'],['Location']]
  },
  initCode: {},
  disclaimer: `<p>ACCEPTANCE OF TERMS OF USE<p>Sweetwater County provides this map service for illustrative purposes only and assumes no liability for actions taken by users based on information shown.`,
  print: {
    disclaimer: "Sweetwater County provides this map for illustrative purposes only and assumes no liability for actions taken by users based on information shown.",
    title: "Sweetwater County Wyoming MapServer"
  },
};
