document.title = 'Big Horn County, Wyoming, MapServer';
const rwgInitParams = {
  utm_zone: '12',
  statePlane: 'EPSG:3737',
  olProjection: { code: 'EPSG:3737', units: 'us-ft' },
  olView: {
    extent: [970000, 1650000, 1375000, 1980000],
    minResolution: 0.2,
    maxResolution: 600
  },
  mapfile: 'MAP09',
  mapserv: '/cgi-bin/mapserv76.fcgi',
  defaultImgTyp: 'png8g',
  otherMaps: {
    'Google': {active: true},
    'Bing': {active: true},
    'Google Earth': {active: true},
    'Pictometry Explorer': {active: location.pathname.includes('assessor') || location.pathname.includes('staff') }
  },
  fullDrawing: true,
  sources: {
    streetno: {url: '/bighorn/mapserver/json-data/streetno.topo.json'},
    lotnum: {url: '/bighorn/mapserver/json-data/lotnum.topo.json'},
    mileposts:  {url: 'json-data/mileposts.topo.json'},
    roads:  {url: '/bighorn/mapserver/json-data/road_cl.topo.json'},
    cities: {url: '/bighorn/mapserver/json-data/towns.topo.json'},
    a25: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts', // URL for TerraGIS including key
      layer: 'PICT-WYSTPB25-oenJczTttd', // this is different for each area
    },	
    a23: {
      type: 'WMTS',
      // attributions: '',
      url: 'https://svc.pictometry.com/Image/F0200C84-B3EE-76AA-E6CA-3408792C3842/wmts',
      layer: 'PICT-WYSTPB23-MP77Hnwq58',
      projection: 'EPSG:3857',
    },
  },
  styles: {
    address: {
      text: {
        font: 'bold 11pt Arial, Helvetica, sans-serif',
        stroke: {color: 'white', width: 2}, // halo
      },
    },
    lotnum: {
      text: {
        font: '12pt Times New Roman, Times, serif',
        fill: {color: '#000080'},
        stroke: {color: '#ffffff', width: 2}, // halo
      }
    },
    labelText: {
      text: {
        font: 'bold 12pt Arial, Helvetica, sans-serif',
        fill: {color: '#000'},
        stroke: {color: 'white', width: 2},
        overflow: true
      },
    },
    roadShadow: {
      stroke: {
        color: '#555555',
        width: 3,
      },
      zIndex: 0,
    },
    roadLine: {
      stroke: {},
      zIndex: 1,
    },
    roadLabel: {
      text: {
        placement: 'line',
        maxAngle: Math.PI / 12,
        font: 'bold 12px Arial',
        fill: {color: 'black'},
        stroke: {color: 'white', width: 1},  // do NOT quote the width!
      },
      zIndex: 2,
    },
    shieldWY: {
      xy: [],
      icon: { src: '/mapserver/wyhwy.png', scale: 0.8},
      text: {
        // offsetX: 1,
        offsetY: 2,
        font: 'bold 12px Arial',
      },
      zIndex: 2,
    },
    shieldUS: {
      xy: [],
      icon: { src: '/mapserver/ushwy.png', scale: 0.9 },
      text: {
        font: 'bold 12px Arial',
        stroke: {
          color: '#fff',
          width: 1,
        },
      },
      zIndex: 2,
    },
    shieldUS2: {  // taller
      xy: [],
      icon: { src: '/mapserver/ushwy.png', scale: [0.9, 1.2] },
      text: {
        font: 'bold 12px Arial',
        stroke: {
          color: '#fff',
          width: 1,
        },
      },
      zIndex: 2,
    },
    cities: {
      stroke: {
        color: [255,128,0],
        width: 5,
        lineDash: [3,8]
      },
      text: {}
    },
    mileposts: {
      text: {
        font: '12pt Arial, Helvetica, sans-serif',
        fill: {color: '#fff'},
        stroke: {color: '#333', width: 3}, // halo
      }
    },
  },
  olLayers: [
    { name: 'a2025',
      source: 'a25',
      // extent: [], // extent should be epsg:3739 despite the source being epsg:3857
    },  
    { name: 'a23',
      source: 'a23',
      extent: [969220, 168500, 1168010, 1973880], // this extent is epsg:3737 despite the source being epsg:3857
    },
    { name: "cities",
      type: 'Vector',
      source: 'cities',
      declutter: true,
      style: f => [
        rwg.styles.get('cities'),
        rwg.styles.get('labelText', {
          text: {text: f.get('NAME')},
          geom: f => f.getGeometry().getType() === 'Polygon' ?
            f.getGeometry().getInteriorPoint() :
            f.getGeometry().getInteriorPoints().getPoint(0) // MultiPolygon
        })
      ],
      zIndex: 9,
    },
    { name: 'roads',
      type: 'Vector',
      source: 'roads',
      declutter: true,
      style: (feature, resolution) => {
        let priority = feature.get('p')
        let txt = feature.get('t')
        let color, width, hwyShield
        let coordAtM = (geom, m) =>
          geom.getType() === 'MultiLineString' ?  geom.getCoordinateAtM(m) : geom.getCoordinateAt(m)
        switch (true) { // resolution
          case (resolution < 3): // ~10k
            width = 5
            break
          case (resolution < 9): // ~30k
            width = 3
            break
          default:
            width = 1
        }
        switch (priority) {
          case 3: // hwy
            // let clippedGeom = rwg.clipToExtent(feature)
            // let p = coordAtM(clippedGeom, 0.5)
            let p = rwg.pointOnLineInView(feature, 0.5)
            if (txt.indexOf('STATE HWY ') === 0) {
              if (p) {
                hwyShield = rwg.styles.get('shieldWY', {
                  xy: p,
                  text: {text: txt.substr(10)}
                })
                txt = false
              }
              color = '#dc2500' // Wyo color: '#ffb307'
            } else {
              if (txt.indexOf('US HWY ') === 0) {
                if (p) {
                  txt = txt.substr(7)
                  if (txt.indexOf(' ') > -1) { // use taller shield
                    hwyShield = rwg.styles.get('shieldUS2', {
                      xy: p,
                      text: {text: txt.replace(' ', '\n')},
                    })
                  } else {
                    hwyShield = rwg.styles.get('shieldUS', {
                      xy: p,
                      text: {text: txt},
                    })
                  }
                  txt = false
                }
              }
              color = '#dc2500'
            }
            width = width + 2
            break;
          case 1: // county
            color = '#fffa73'
            width = width + 1
            break;
          default:
            color = "#eeeeee"
            break;
        }
        let style = [
          rwg.styles.get('roadShadow', {stroke: {width: width + 1}}),
          rwg.styles.get('roadLine', {stroke: {width: width, color: color} }),
        ]
        if (txt) {
          let geom = rwg.clipToExtent(feature)
          if (geom) {
            style.push(rwg.styles.get('roadLabel', { text: {text: txt}, geom: geom}))
          }
        }
        if (hwyShield) {
          style.push(hwyShield)
        }
        return style
      }
    },
    { name: 'lotnum',
      source:'lotnum',
      type: 'Vector',
      style: feature => rwg.styles.get('lotnum', {text: {text: feature.get('n')}}),
      declutter: true,
    },
    { name: 'streetnum',
      type: 'Vector',
      source: 'streetno',
      style: feature => rwg.styles.get('address', { text: { text: feature.get('n')}}),
      declutter: true,
    },
    { name: "mileposts",
      type: 'Vector',
      source: 'mileposts',
      declutter: true,
      zIndex: 9,
      style: f =>rwg.styles.get('mileposts' , {
        text: {text: f.get('n').toString()}
      }),
    },
  ],
  layerOptions: {
    a2025: {
      // imgType: 'jpeg', // using Eagleview WMTS 
      info: () => {}
    },
    a22: {imgType: 'jpeg'},
    a20: {imgType: 'jpeg'},
    a19: {imgType: 'jpeg'},
    a17: {imgType: 'jpeg'},
    a15: {imgType: 'jpeg'},
    a12: {imgType: 'jpeg'},
    a09: {imgType: 'jpeg'},
    drg: {imgType: 'jpeg'},
    range_owner: { info: (records) => rwg.formatInfo(records, [['Abstract Code'],['LRA'],['Soils Class'],['Acres'],['Account']],'Rangeland')},
    irr_owner: { info: (records) => rwg.formatInfo(records, [['Abstract Code'],['LRA'],['Soils Class'],['Acres'],['Account']],'Irrigated land')},
    ownership: { info: (records) => {
      let count = rwg.selection.ownership.update(records);
      if (count) {
        rwg.filter = "(pidn in(" + rwg.selection.ownership.getIdArray().join(",") + "))";
        rwg.historyManager.push();
        return rwg.selection.ownership.render( null,
          '<table style="width: 100%"><tr><td>' + count +
          ' Parcel(s)</td> <td style="text-align:right"><a href="javascript:rwg.zoomToVectorExtents()">Zoom to parcel(s)</a></td></tr></table>',
          '<div style="color: red">* Location is not for use in legal documents.</div>'
        );
      }
    }},
    cornerrec: { info: records => rwg.formatInfo(records, [['Corner Record', (dat) => `<a href="https://gwmap.s3.amazonaws.com/bighorn/corners/${dat}.pdf" target="_blank">View</a>` ]])},
  },
  navbar: {
    jump2s: [
      {"Big Horn County": [ 970000, 1650000, 1375000, 1980000]},
      {"Basin": [1117204, 1736923, 1136369, 1747710]},
      {"Burlington": [1019009, 1760553, 1032371, 1774377]},
      {"Byron": [1002705, 1889713, 1012032, 1900447]},
      {"Cowley": [1014406, 1923263, 1020673, 1932062]},
      {"Deaver": [979764, 1924274, 990300 , 1936330]},
      {"Frannie": [977843, 1954725, 984409 , 1966473]},
      {"Greybull": [1110984, 1778640, 1133709, 1791387]},
      {"Lovell": [1031644, 1906123, 1043205, 1913120]},
      {"Manderson": [1143314, 1698162, 1150924, 1706035]}
    ],
  },
  disclaimer: `<p>ACCEPTANCE OF TERMS OF USE FOR THIS WEBSITE
    <p>PLEASE READ THIS AGREEMENT CAREFULLY BEFORE USING THIS WEBSITE. BY USING THIS WEBSITE, YOU ARE CONSENTING TO BE OBLIGATED AND BECOME A PARTY TO THIS AGREEMENT.
    IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS BELOW, YOU SHOULD NOT ACCESS OR USE THIS WEBSITE.
    <p>This website is offered as a public service that provides internet accessibility to geographic information system (GIS) data and related information
    (hereinafter referred to as the &quot;data&quot;) provided by Big Horn County and, potentially, other state and federal entities.
    Due to the dynamic nature of the data contained within this website and the reliance on information from outside sources,
    Big Horn County and its affiliated entities, elected and appointed officers, officials, employees and agents
    (hereinafter referred to as the &quot;County&quot;) make no warranty, representation or guarantee as to the accuracy, completeness or reliability of the data
    presented on this website. This website and the data available on this website are provided &quot;as is&quot; for you to view, access and otherwise use for
    generalized reference purposes only, at your own risk. The County and Terra GIS Ltd. assume no liability for any errors, omissions, or inaccuracies in the data provided,
    regardless of cause. The County and Terra GIS Ltd. assume no liability for any decisions made or actions taken or not taken by the user of the data in reliance upon any data furnished hereunder.<p>Some GIS data layers may appear to be misaligned relative to others. Individual layers have been developed for different purposes, at different times, often with varying technical procedures carried out by different individuals or agencies. The data contained on the maps is used to locate, identify and inventory parcels of land in Big Horn County for reference purposes only and is NOT to be construed or used as a &quot;legal description.&quot; Actual legal property descriptions are recorded in the Big Horn County Clerk&apos;s office as deeds, plats or other legally recorded documents.`,
  print: {
    disclaimer: "Big Horn County provides this map for illustrative purposes only and assumes no liability for actions taken by users based on information shown.",
    title: "Big Horn County Wyoming MapServer"
  },
  selectionSets: {
    ownership: [
      ['Parcel'],
      ['Account#',   dat => `<a href="javascript:rwg.detailTab('${dat}')">Property&nbsp;Detail</a>` ],
      ['Tax ID',     dat => `<a href="https://property.bighorncountywy.gov/ParcelSearchResults.aspx?Parcel=${dat}" target="_blank">Property Taxes</a>` ],
      ['Map Number', dat => `<a href="https://gwmap.s3.amazonaws.com/bighorn/subdivisions/${dat}.pdf" target="_blank">Scanned Map<\/a>` ],
      ['Tax District'],
      ['Lot'],['Name'],['Mail Addr'],['Mail Addr'],
      ['St Addr'],['Location*'],['Tax Classification'],['Tax Roll Acreage'],
      [false, dat => rwg.mapFeatures(dat)],
      [false, dat => rwg.mapFeatures(dat)],
      ['LEA'],
      ['Neighborhood'],
      ['Value measure'],
      ['Quality'],
      ['Condition'],
      ['Effective age'],
      ['Detailed Review Date']
    ]
  }
};
