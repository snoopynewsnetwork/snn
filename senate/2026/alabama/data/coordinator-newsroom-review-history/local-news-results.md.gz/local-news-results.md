# Alabama newsroom and NYT backstops

Research observed **2026-10-18 UTC / 2026-10-17 Central**. This is coordinator preparation; four state question assignments and integration remain pending. [Retained responses](data/news/manifest.json) preserve UTC retrieval, URLs, HTTP status/headers and exact compressed/raw hashes. No November live collector or complete state package is claimed.

| Region/product | Primary source | Actual observation |
| --- | --- | --- |
| Birmingham / central Alabama — WBRC | [Results page](https://www.wbrc.com/politics/election-results/) | HTTP 200, no selected election in the inspected result configuration and test display enabled. An empty/unselected product is not a zero-vote Senate count. November configuration and supplier remain unverified. |
| Montgomery / south-central Alabama — WSFA | [Actual results page](https://www.wsfa.com/politics/election-results) | HTTP 200; selects inactive **2743, 2026 General Election**, with `displayTestData:true`. Displayed local zeroes/0-of-0 completion belong to preflight/test state, not established November returns or final ballot inventory. |
| Huntsville / north Alabama — WAFF | [Homepage](https://www.waff.com/) | HTTP 200 confirms regional reporting access; no actual November numeric product or cadence established from this landing page. |
| Statewide original reporting — Alabama Reflector | [Homepage](https://alabamareflector.com/) | Direct 403; research-browser current homepage confirms original state reporting. Actual count product/access remains unverified; preserve original author/upstream attribution for manual contextual reports. |
| Mobile / Gulf Coast — WKRG | [Homepage](https://www.wkrg.com/) | Direct 403. Exact November scoreboard, supplier, geographic coverage and automated access remain gaps. |

The [SOS primary announcement](https://www.sos.alabama.gov/newsroom/secretary-state-wes-allen-announces-unofficial-primary-election-results-are-available) was retained HTTP 200. It explicitly concerns **May 19 primary** returns from counties and links AlabamaVotes. It does not establish November setup or a guaranteed update interval. The official-results worker must verify actual county probate/election-office authority, native precinct/method records and November slate/rules. Congressional special-primary/redistricting dates must not be assumed to define statewide Senate count geography. No current county feed is inferred from a May announcement.

An **October20 UTC** bounded regional followup retains
[three complete requests](data/news/coordinator-oct20-regional/acquisition-complete-v1.json)
and a [complete embedded-widget review](data/news/coordinator-oct20-regional/review.json).
Wiregrass broadcaster [WTVY's results page](https://www.wtvy.com/politics/election-results/)
returns200. Its fresh raw body selects inactive2782, General Election–Alabama,
with24 zero-vote races, while frontend displayTestData is true and the embedded
backend request says includeTestResults false. Complete objects retain all
fields and the separate Alabama/Georgia/Florida election choices. A cached
web-reader view still presents special House primaries; no correction cause or
November-valid count sequence is inferred. The source Senate setup identifiers
are unapproved. WTVY's [May19 primary report](https://www.wtvy.com/2026/05/20/decision-2026-primary-results-across-area-state/)
also returns200, with its primary stage preserved. On the Gulf Coast,
[Lagniappe's September15 public preview](https://www.lagniappemobile.com/news/alabama/election_2026/voters-to-decide-on-school-prayer-pledge-taxes/article_0ef75690-a78e-4559-87ec-b6a2cdda426c.html)
returns200 with November-amendment context; protected/encoded text was not
decoded or bypassed. These observations establish no genuine Senate counts,
measured cadence or independent count supplier. The earlier ledger is unchanged.

Treat common upstream suppliers, official reprints and shared newsroom reporting as overlapping evidence. Compare identical election/contest/candidate/unit/method/stage at compatible timestamps. Never add cumulative snapshots, a statewide total and its local components, or two suppliers' views of the same votes. Preserve corrections and decreases. Calls, estimated vote completion and probability forecasts remain separately attributed fields.

[NYT's election hub](https://www.nytimes.com/section/politics/elections) returned direct HTTP 403. Discover the actual November Senate product from current navigation; geographic detail, supplier attribution, automated access and cadence remain unverified. A timestamped manual comparison is the fallback. The [state strategy](live-polling-strategy.md) distinguishes proposed checks from observed publication behavior.
