"""Actual corruptions, retained as exact patches against whole pinned inputs."""
import copy,gzip,json
from pathlib import Path
from replay_authority import STATE,OWN,CONTRACT,loadpin,parse,semantic,digest,verify
from build_data import validate,dump

def pointer_set(o,path,value):
    keys=path.strip('/').split('/');cur=o
    for k in keys[:-1]:cur=cur[int(k)] if isinstance(cur,list) else cur[k]
    k=int(keys[-1]) if isinstance(cur,list) else keys[-1]
    old=copy.deepcopy(cur[k]);cur[k]=value
    return cur,k,old

def test_contract(c):
    # Whole exact original root semantics reject changes even when arithmetic still balances.
    a=parse((STATE/'data/coordinator-priority-acceptance.json').read_bytes())
    for f in a['complete_root_field_semantics']:
        assert semantic(c[f['pointer'][1:]])==f['full_recursive_semantic_sha256']

def run(write=True):
    hraw=(OWN/'historical-hierarchy.json.gz').read_bytes();h=parse(gzip.decompress(hraw));validate(h)
    c=parse(loadpin(CONTRACT));test_contract(c)
    base={'path':'historical-hierarchy.json.gz','bytes':len(hraw),'sha256':digest(hraw),
          'reconstruct':'gzip.decompress whole body, parse strict JSON, apply exact JSON-pointer replacement'}
    fixtures=[]
    hcases=[('missing-native','/source_contexts',h['source_contexts'][:-1]),
      ('missing-parent','/parents',h['parents'][:-1]),
      ('county-substitute','/full_order',[p['parent_key'] for p in h['parents']]),
      ('reordered-priority','/ordered_priority',list(reversed(h['ordered_priority']))),
      ('reordered-remainder','/ordered_remainder',list(reversed(h['ordered_remainder']))),
      ('wrong80','/threshold_integer',1812071),('residual-allocation','/remainder_votes',452271),
      ('changed-count','/source_contexts/0/reported_candidate_votes',15692),
      ('wrong-rank','/source_contexts/0/rank',2),('wrong-mask','/source_contexts/0/priority',False),
      ('numeric-label-alias','/source_contexts/0/key','1'),
      ('wrong-source-column','/source_contexts/0/original_member/column_1based',6),
      ('wrong-original-member','/source_contexts/0/original_member/name','2024-General-Autauga.xls'),
      ('wrong-context-pointer','/source_contexts/0/full_own_source_context/pointer','/units/1'),
      ('truncated-source-context','/source_contexts/0/full_own_source_context',{'pointer':'/units/0'}),
      ('current-native-id','/source_contexts/0/current_native_id','0081'),
      ('current-choice-id','/source_contexts/0/current_choice_id','001'),
      ('current-match','/source_contexts/0/current_match','ABSENTEE'),
      ('unproved-CRS','/source_contexts/0/geometry_crs','EPSG:4326'),
      ('unproved-vintage','/source_contexts/0/geography_vintage','2026'),
      ('November-admission','/parents/0/November_votes_admitted',True),
      ('current-legal-admission','/approvals/current_legal',True),
      ('eligible-writein-admission','/approvals/eligible_named_writein',True),
      ('wrong-parent-array','/parents/0/full_source_rank_ordered_children',h['parents'][0]['full_source_rank_ordered_children'][:-1])]
    ccases=[('candidate-truncation','/units/0/candidate_votes',c['units'][0]['candidate_votes'][:-1]),
      ('party-change','/units/0/candidate_votes/0/party_literal','REP'),
      ('candidate-null-to-zero','/units/0/candidate_votes/0/raw_value',0),
      ('administrative-truncation','/units/0/administrative_fields',[]),
      ('raw-source-position','/units/0/candidate_votes/0/row_1based',11),
      ('method-change','/units/0/method_context','election_day'),
      ('native-header-alias','/units/0/native_label','1'),
      ('registration-null-inference','/units/0/registration_source',None),
      ('under-over-residual','/units/0/under_votes_source',49),
      ('duplicate-native-key','/units/1/key',c['units'][0]['key']),
      ('raw-context-truncation','/units/0/contest_other_fields',[])]
    for scope,obj,cases,check,pin in [('hierarchy',h,hcases,validate,base),('contract',c,ccases,test_contract,CONTRACT)]:
        for name,path,val in cases:
            cur,key,old=pointer_set(obj,path,val)
            try:
                try:check(obj)
                except (AssertionError,ValueError,KeyError,IndexError,TypeError) as e:
                    result={'status':'REJECTED','exception':type(e).__name__,'reason':str(e)}
                else:raise AssertionError('negative fixture accepted: '+name)
            finally:cur[key]=old
            fixture={'name':name,'scope':scope,'base':pin,'patch':{'op':'replace','pointer':path,'value':val},'actual_result':result}
            fixtures.append(fixture)
    # Real whole-byte truncation and complete companion replacement, not projected field samples.
    for name,pin,b in [('truncated-original-contract',CONTRACT,loadpin(CONTRACT)[:-1]),
                       ('whole-companion-replaced',next(x for x in parse((STATE/'data/coordinator-priority-acceptance.json').read_bytes())['complete_source_companion_files'] if x['path']=='data/turnout/candidate-universe.json'),b'[]')]:
        try:verify(b,pin)
        except AssertionError:pass
        else:raise AssertionError('byte corruption admitted')
        fixtures.append({'name':name,'base':pin,'byte_patch':{'op':'drop-last-byte'} if name.startswith('truncated') else {'op':'replace-whole','utf8':'[]'},'actual_result':{'status':'REJECTED','rule':'whole original size/SHA'}})
    raw=gzip.decompress(hraw); marker=b'"schema":';at=raw.index(marker)
    bad=raw[:at]+b'"schema":null,'+raw[at:]
    try:parse(bad)
    except ValueError:pass
    else:raise AssertionError('duplicate JSON fields admitted')
    fixtures.append({'name':'duplicate-JSON-key','base':base,'byte_patch':{'offset':at,'insert_utf8':'"schema":null,'},'actual_result':{'status':'REJECTED','rule':'strict duplicate JSON field parser'}})
    if write:
        out=OWN/'qa/fixtures';out.mkdir(exist_ok=True)
        for f in fixtures:(out/(f['name']+'.json')).write_bytes(dump(f))
        (OWN/'qa/negative-validation.json').write_bytes(dump({'status':'PASS','rejected':len(fixtures),'all_actual_inputs_reconstructable':True,
             'acceptance_path':'data/coordinator-priority-acceptance.json','current_admission':False}))
    return {'status':'PASS','rejected':len(fixtures)}
if __name__=='__main__':
    import sys
    print(json.dumps(run('--audit' not in sys.argv)))
